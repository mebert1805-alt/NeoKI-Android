package de.neoki.app

import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.result.ActivityResult
import androidx.compose.foundation.horizontalScroll
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

private val dark = Color(0xFF11172B)
private val teal = Color(0xFF079F8A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("neo_prefs", MODE_PRIVATE)
        val deviceId = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("device_id", it).apply()
        }
        val secretStore = SecretStore(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = dark, secondary = teal)) {
                NeoScreen(
                    id = deviceId,
                    initialUrl = prefs.getString("server_url", "https://neoki-gedaechtnis-test.mebert1805.workers.dev") ?: "",
                    initialToken = secretStore.read(),
                    initialLearn = prefs.getBoolean("auto_learn", true),
                    initialWeb = prefs.getBoolean("use_web", false),
                    initialWork = prefs.getBoolean("work_mode", false),
                    initialAdult = prefs.getBoolean("adult_mode", false),
                    initialStyle = prefs.getString("chat_style", "natural") ?: "natural",
                    initialProactive = prefs.getBoolean("proactive", true),
                    initialSmart = prefs.getBoolean("smart_mode", false),
                    initialReview = prefs.getBoolean("quality_review", false),
                    saveUrl = { prefs.edit().putString("server_url", it).apply() },
                    saveToken = { secretStore.save(it) },
                    saveLearn = { prefs.edit().putBoolean("auto_learn", it).apply() },
                    saveWeb = { prefs.edit().putBoolean("use_web", it).apply() },
                    saveWork = { prefs.edit().putBoolean("work_mode", it).apply() },
                    saveAdult = { prefs.edit().putBoolean("adult_mode", it).apply() },
                    saveStyle = { prefs.edit().putString("chat_style", it).apply() },
                    saveProactive = { prefs.edit().putBoolean("proactive", it).apply() },
                    saveSmart = { prefs.edit().putBoolean("smart_mode", it).apply() },
                    saveReview = { prefs.edit().putBoolean("quality_review", it).apply() }
                )
            }
        }
    }
}

@Composable
fun NeoScreen(
    id: String, initialUrl: String, initialToken: String, initialLearn: Boolean, initialWeb: Boolean, initialWork: Boolean,
    initialAdult: Boolean, initialStyle: String, initialProactive: Boolean, initialSmart: Boolean,
    initialReview: Boolean,
    saveUrl: (String) -> Unit, saveToken: (String) -> Unit, saveLearn: (Boolean) -> Unit,
    saveWeb: (Boolean) -> Unit, saveWork: (Boolean) -> Unit, saveAdult: (Boolean) -> Unit,
    saveStyle: (String) -> Unit, saveProactive: (Boolean) -> Unit,
    saveSmart: (Boolean) -> Unit, saveReview: (Boolean) -> Unit
) {
    var url by remember { mutableStateOf(initialUrl) }
    var urlDraft by remember { mutableStateOf(initialUrl) }
    var token by remember { mutableStateOf(initialToken) }
    var tokenDraft by remember { mutableStateOf("") }
    var learn by remember { mutableStateOf(initialLearn) }
    var useWeb by remember { mutableStateOf(initialWeb) }
    var work by remember { mutableStateOf(initialWork) }
    var adultMode by remember { mutableStateOf(initialAdult) }
    var chatStyle by remember { mutableStateOf(initialStyle.takeIf { it in listOf("natural", "warm", "direct") } ?: "natural") }
    var proactive by remember { mutableStateOf(initialProactive) }
    var smartMode by remember { mutableStateOf(initialSmart) }
    var qualityReview by remember { mutableStateOf(initialReview) }
    var lessonDialog by remember { mutableStateOf(false) }
    var lessonDraft by remember { mutableStateOf("") }
    var lessonBusy by remember { mutableStateOf(false) }
    var adultConfirm by remember { mutableStateOf(false) }
    var adultChecking by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(if (initialUrl.isBlank() || initialToken.isBlank()) 4 else 0) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var memories by remember { mutableStateOf<List<MemoryItem>>(emptyList()) }
    var knowledge by remember { mutableStateOf<List<KnowledgeItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var knowledgeTitle by remember { mutableStateOf("") }
    var knowledgeBody by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var attachedImage by remember { mutableStateOf<ByteArray?>(null) }
    var attachedImageName by remember { mutableStateOf("") }
    var attachedDocument by remember { mutableStateOf<SelectedDocument?>(null) }
    var loadingAttachment by remember { mutableStateOf(false) }
    var imagePrompt by remember { mutableStateOf("") }
    var imageBytes by remember { mutableStateOf<ByteArray?>(null) }
    var imageBusy by remember { mutableStateOf(false) }
    var imageInfo by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmClearChat by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val api = remember(url, token) { Api(url, token) }
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val imageBitmap = remember(imageBytes) {
        imageBytes?.let { bytes ->
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }
    }
    val attachmentPreview = remember(attachedImage) {
        attachedImage?.let { bytes ->
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }
    }
    val saveImage = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/jpeg")
    ) { uri ->
        val jpeg = imageBytes
        if (uri != null && jpeg != null) {
            scope.launch {
                try {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(jpeg) }
                            ?: error("Datei konnte nicht geöffnet werden")
                    }
                    imageInfo = "Bild gespeichert."
                } catch (e: Exception) {
                    imageInfo = "Speichern fehlgeschlagen: ${e.message}"
                }
            }
        }
    }
    val chooseImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            loadingAttachment = true
            scope.launch {
                try {
                    attachedImage = AttachmentTools.loadImage(context, uri)
                    attachedImageName = AttachmentTools.fileName(context, uri)
                    attachedDocument = null
                    notice = "Bild angehaengt. Stelle eine Frage und tippe Senden."
                } catch (e: Exception) { notice = "Bild konnte nicht geladen werden: ${e.message}" }
                finally { loadingAttachment = false }
            }
        }
    }
    val chooseDocument = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            loadingAttachment = true
            scope.launch {
                try {
                    attachedDocument = AttachmentTools.loadDocument(context, uri)
                    attachedImage = null
                    attachedImageName = ""
                    notice = "Dokument gelesen. Stelle eine Frage und tippe Senden."
                } catch (e: Exception) { notice = "Dokument konnte nicht geladen werden: ${e.message}" }
                finally { loadingAttachment = false }
            }
        }
    }
    // Kamera ueber die installierte Kamera-App; kein permanenter Kamerazugriff.
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) {
            try {
                attachedImage = AttachmentTools.toJpeg(bmp)
                attachedImageName = "Kamerafoto.jpg"
                attachedDocument = null
                notice = "Foto angehaengt. Stelle eine Frage zum Bild."
            } catch (e: Exception) { notice = "Foto konnte nicht verwendet werden: ${e.message}" }
        }
    }
    // Diktat ueber die Android-Spracherkennung; Start nur durch aktiven Tastendruck.
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            val recognized = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!recognized.isNullOrBlank()) input = (input.trim() + " " + recognized).trim().take(3000)
        }
    }
    fun createPicture() {
        val prompt = imagePrompt.trim()
        if (prompt.length !in 4..700 || imageBusy || url.isBlank() || token.isBlank()) return
        imageBusy = true
        imageInfo = "Neo KI erzeugt dein Bild …"
        imageBytes = null
        scope.launch {
            try {
                imageBytes = api.generateImage(prompt)
                imageInfo = "Bild erstellt. Du kannst es jetzt speichern."
            } catch (e: Exception) {
                imageInfo = "Bildgenerierung fehlgeschlagen: ${e.message}"
            } finally {
                imageBusy = false
            }
        }
    }


    fun reload() {
        if (url.isBlank() || token.isBlank()) return
        scope.launch {
            try {
                memories = api.memories()
                knowledge = api.knowledge()
                notice = null
            } catch (e: Exception) {
                notice = "Verbindung fehlgeschlagen: ${e.message}"
            }
        }
    }

    LaunchedEffect(url, token) { if (url.isNotBlank() && token.isNotBlank()) reload() }

    fun send() {
        val text = input.trim()
        val image = attachedImage
        val imageName = attachedImageName
        val document = attachedDocument
        if ((text.isBlank() && image == null && document == null) || busy || loadingAttachment || url.isBlank() || token.isBlank()) return
        val question = text.ifBlank { if (image != null) "Was ist auf diesem Bild zu sehen?" else "Fasse das Dokument zusammen." }
        input = ""
        attachedImage = null
        attachedImageName = ""
        attachedDocument = null
        busy = true
        notice = null
        val adultForThisMessage = adultMode
        val history = messages.takeLastWhile { it.adultMode == adultForThisMessage }.takeLast(8)
        val visible = when {
            image != null -> "📷 $imageName\n$question"
            document != null -> "📄 ${document.name}\n$question"
            else -> question
        }
        messages = messages + ChatMessage("user", visible, adultMode = adultForThisMessage)
        scope.launch {
            try {
                val reply = when {
                    image != null -> api.analyzeImage(question, image)
                    document != null -> api.analyzeDocument(question, document, smartMode)
                    else -> api.chat(question, adultForThisMessage, history, chatStyle, proactive, smartMode, qualityReview)
                }
                messages = messages + ChatMessage("assistant", reply.answer, adultMode = adultForThisMessage,
                    learningSuggestion = reply.learningSuggestion, modelUsed = reply.modelUsed,
                    reviewStatus = reply.reviewStatus, reviewWarning = reply.reviewWarning,
                    appliedRuleIds = reply.appliedRuleIds)
                if (reply.fallback) notice = "Starkes Modell momentan nicht erreichbar; Neo hat mit dem Standardmodell geantwortet."
                memories = api.memories()
            } catch (e: Exception) {
                notice = "Antwort fehlgeschlagen: ${e.message}"
                messages = messages.dropLast(1)
                input = text
                attachedImage = image
                attachedImageName = imageName
                attachedDocument = document
            } finally { busy = false }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF6F8FC),
        topBar = {
            Row(Modifier.fillMaxWidth().background(dark).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEO KI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Chat · Bilder · Gedächtnis · Wissen", color = Color(0xFFC7D4ED), fontSize = 12.sp)
                }
                Text(if (url.isBlank() || token.isBlank()) "Setup fehlt" else "Zugang gespeichert", color = Color(0xFF8CF3D8), fontSize = 12.sp)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Chat", "Bilder", "Wissen", "Gedächtnis", "Setup").forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index; notice = null; if (index in 2..3) reload() },
                        icon = { Text(listOf("✦", "▧", "▤", "♡", "⚙")[index], fontSize = 22.sp) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (notice != null) {
                Surface(color = Color(0xFFFFEBE5)) {
                    Text(notice ?: "", Modifier.fillMaxWidth().padding(12.dp), color = Color(0xFF922D1B))
                }
            }
            when (tab) {
                0 -> {
                    Text(if (adultMode)
                            "Erwachsenenmodus aktiv · offene Gespraeche ueber erwachsene Themen. Die Sicherheitsgrenzen bleiben bestehen."
                        else "Standardmodus · Chat und Recherche. Bilder kannst du im Reiter Bilder erzeugen.",
                        Modifier.fillMaxWidth().background(Color.White).padding(12.dp),
                        fontSize = 12.sp, color = if (adultMode) Color(0xFF65508D) else Color.Gray)
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("Gespraechskontext: letzte Nachrichten · " + when (chatStyle) {
                            "warm" -> "herzlich"; "direct" -> "direkt"; else -> "natuerlich"
                        }, fontSize = 12.sp,
                            color = Color.DarkGray, modifier = Modifier.weight(1f))
                        TextButton(onClick = { lessonDraft = ""; lessonDialog = true },
                            enabled = !busy && !lessonBusy && token.isNotBlank()) {
                            Text("Lernregel", fontSize = 12.sp)
                        }
                        TextButton(onClick = { confirmClearChat = true }, enabled = messages.isNotEmpty() && !busy) {
                            Text("Neuer Chat", fontSize = 12.sp)
                        }
                    }
                    val state = rememberLazyListState()
                    LaunchedEffect(messages.size, busy) {
                        if (messages.isNotEmpty()) state.animateScrollToItem(messages.lastIndex)
                    }
                    LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (messages.isEmpty()) item {
                            Column(Modifier.fillMaxWidth().padding(top = 58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("✦", fontSize = 50.sp, color = teal)
                                Text("Hallo! Ich bin Neo.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Ich beantworte Fragen und verwende deine gespeicherten Erinnerungen und Wissensnotizen.",
                                    textAlign = TextAlign.Center, color = Color.DarkGray)
                                if (url.isBlank() || token.isBlank()) {
                                    Spacer(Modifier.height(20.dp))
                                    Button(onClick = { tab = 4 }) { Text("Server verbinden") }
                                }
                            }
                        }
                        items(messages) { message ->
                            val isUser = message.role == "user"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                                Surface(modifier = Modifier.fillMaxWidth(0.92f),
                                    color = if (isUser) dark else Color.White,
                                    shape = RoundedCornerShape(16.dp), shadowElevation = if (isUser) 0.dp else 2.dp) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(message.content, color = if (isUser) Color.White else dark, fontSize = 15.sp)
                                        if (!isUser && message.sources.isNotEmpty()) {
                                            Spacer(Modifier.height(8.dp))
                                            Text("Internetquellen:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            message.sources.forEach { source ->
                                                TextButton(onClick = {
                                                    if (source.url.startsWith("https://") || source.url.startsWith("http://"))
                                                        uriHandler.openUri(source.url)
                                                }) { Text(source.title, maxLines = 2, fontSize = 12.sp) }
                                            }
                                        }
                                        if (!isUser) {
                                            message.modelUsed?.let { used ->
                                                Text(when { used.contains("70b") -> "KI-Modell: Llama 3.3 70B"
                                                        used.contains("mistral-small") -> "KI-Modell: Mistral Vision (Bildanalyse)"
                                                        else -> "KI-Modell: Standard" },
                                                    fontSize = 11.sp, color = Color.Gray)
                                            }
                                            if (message.appliedRuleIds.isNotEmpty()) {
                                                Text("An Modell uebergebene Lernregeln: " + message.appliedRuleIds.joinToString(", ") { "#$it" },
                                                    fontSize = 11.sp, color = Color(0xFF22736A))
                                            }
                                            when (message.reviewStatus) {
                                                "ok" -> Text("Antwortpruefung: Keine eindeutigen Widersprueche erkannt (keine Faktenpruefung).",
                                                    fontSize = 11.sp, color = Color.Gray)
                                                "warning" -> Text("Pruefhinweis (KI-basiert, ungeprueft): " + (message.reviewWarning ?: "Moegliches Problem."),
                                                    fontSize = 12.sp, color = Color(0xFF99511A))
                                                "unavailable" -> Text("Antwortpruefung momentan nicht verfuegbar.",
                                                    fontSize = 11.sp, color = Color.Gray)
                                            }
                                            message.learningSuggestion?.let { suggestion ->
                                                Spacer(Modifier.height(6.dp))
                                                Text("Lernvorschlag (noch nicht gespeichert): $suggestion",
                                                    color = Color(0xFF225F57), fontSize = 12.sp)
                                                TextButton(onClick = {
                                                    lessonDraft = suggestion
                                                    lessonDialog = true
                                                }) { Text("Vorschlag pruefen und speichern", fontSize = 12.sp) }
                                            }
                                            TextButton(onClick = {
                                                scope.launch {
                                                    try {
                                                        api.addKnowledge("Gespeicherte KI-Antwort", message.content.take(8000))
                                                        knowledge = api.knowledge()
                                                        notice = "Antwort als Wissenseintrag gespeichert. Bitte Fakten prüfen."
                                                    } catch (e: Exception) { notice = "Speichern fehlgeschlagen: ${e.message}" }
                                                }
                                            }, enabled = url.isNotBlank() && token.isNotBlank()) { Text("Ins Wissen übernehmen", fontSize = 12.sp) }
                                        }
                                    }
                                }
                            }
                        }
                        if (busy) item { Text("Neo bearbeitet deine Anfrage …", color = Color.Gray) }
                    }
                    Column(Modifier.fillMaxWidth().background(Color.White)) {
                        if (attachedImage != null || attachedDocument != null) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(if (attachedImage != null) "📷 Bild: $attachedImageName"
                                     else "📄 Dokument: ${attachedDocument?.name}",
                                    modifier = Modifier.weight(1f), maxLines = 2, fontSize = 12.sp, color = teal)
                                TextButton(onClick = { attachedImage = null; attachedImageName = ""; attachedDocument = null }) {
                                    Text("Entfernen")
                                }
                            }
                            attachmentPreview?.let { preview ->
                                Image(bitmap = preview, contentDescription = "Ausgewaehltes Bild vor dem Senden",
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 3.dp).size(82.dp),
                                    contentScale = ContentScale.Crop)
                            }
                            if (attachedDocument?.truncated == true) {
                                Text("Nur ein gekuerzter Textauszug wird analysiert.",
                                    modifier = Modifier.padding(horizontal = 14.dp), fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { chooseImage.launch("image/*") },
                                enabled = !busy && !loadingAttachment) { Text("🖼 Bild", fontSize = 12.sp) }
                            OutlinedButton(onClick = { chooseDocument.launch("*/*") },
                                enabled = !busy && !loadingAttachment) { Text("📄 Dokument", fontSize = 12.sp) }
                            OutlinedButton(onClick = { camera.launch(null) },
                                enabled = !busy && !loadingAttachment) { Text("📷 Kamera", fontSize = 12.sp) }
                            OutlinedButton(onClick = {
                                try {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
                                        .putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich jetzt mit Neo KI")
                                    speech.launch(intent)
                                } catch (e: Exception) { notice = "Keine Android-Spracherkennung verfuegbar: ${e.message}" }
                            }, enabled = !busy && !loadingAttachment) { Text("🎙 Sprechen", fontSize = 12.sp) }
                        }
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(value = input, onValueChange = { if (it.length <= 3000) input = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("Frage oder Arbeitsauftrag …") },
                            maxLines = 4, enabled = !busy,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { send() }))
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { send() },
                            enabled = !busy && !loadingAttachment && (input.isNotBlank() || attachedImage != null || attachedDocument != null) && url.isNotBlank(),
                            contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Senden") }
                    }
                    }
                }
                1 -> {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Neo KI Bildstudio", style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                        Text("Beschreibe ein Bild. Neo KI erzeugt es über deinen geschützten Cloudflare-Server.",
                            color = Color.DarkGray, fontSize = 13.sp)
                        OutlinedTextField(
                            value = imagePrompt,
                            onValueChange = { if (it.length <= 700) imagePrompt = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                            label = { Text("Bildbeschreibung (4–700 Zeichen)") },
                            placeholder = { Text("Fotorealistisches Porträt einer erwachsenen Person bei Tageslicht …") },
                            maxLines = 6,
                            enabled = !imageBusy
                        )
                        Button(
                            onClick = { createPicture() },
                            enabled = !imageBusy && imagePrompt.trim().length in 4..700 &&
                                url.isNotBlank() && token.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (imageBusy) "Bild wird erzeugt …" else "Bild erzeugen") }
                        if (imageBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        if (imageInfo != null) Text(imageInfo ?: "", fontSize = 13.sp)
                        if (url.isBlank() || token.isBlank()) {
                            TextButton(onClick = { tab = 4 }) { Text("Zuerst Server im Setup verbinden") }
                        }
                        if (imageBitmap != null) {
                            Surface(color = Color.White, shape = RoundedCornerShape(14.dp), shadowElevation = 2.dp) {
                                Image(
                                    bitmap = imageBitmap,
                                    contentDescription = "Von Neo KI erzeugtes Bild",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxWidth().heightIn(max = 470.dp)
                                )
                            }
                            Button(onClick = { saveImage.launch("neo-ki-bild.jpg") },
                                modifier = Modifier.fillMaxWidth()) { Text("Bild als JPG speichern") }
                        }
                        Text("Das Bild bleibt bis zum Schließen der App im Arbeitsspeicher. " +
                            "Für eine dauerhafte Kopie nutze den Speicherknopf. " +
                            "Bilder verbrauchen das kostenlose Workers-AI-Kontingent.",
                            fontSize = 12.sp, color = Color.Gray)
                    }
                }
                2 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Deine Wissensdatenbank", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Eigene Daten speichern oder KI-Antworten aus dem Chat übernehmen. Neo nutzt passende Einträge.",
                            fontSize = 12.sp, color = Color.Gray)
                        OutlinedTextField(value = knowledgeTitle, onValueChange = { if (it.length <= 120) knowledgeTitle = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Titel / Thema") }, singleLine = true)
                        OutlinedTextField(value = knowledgeBody, onValueChange = { if (it.length <= 1700) knowledgeBody = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp), label = { Text("Wissen / Notizen (max. 1700 Zeichen)") }, maxLines = 5)
                        Button(onClick = {
                            scope.launch {
                                try {
                                    api.addKnowledge(knowledgeTitle.trim(), knowledgeBody.trim())
                                    knowledgeTitle = ""; knowledgeBody = ""; knowledge = api.knowledge()
                                    notice = "Wissenseintrag gespeichert."
                                } catch (e: Exception) { notice = "Fehler: ${e.message}" }
                            }
                        }, enabled = url.isNotBlank() && token.isNotBlank() && knowledgeTitle.isNotBlank() && knowledgeBody.isNotBlank()) {
                            Text("Wissen speichern")
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(knowledge, key = { it.id }) { item ->
                                Surface(shape = RoundedCornerShape(12.dp), color = Color.White) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text(item.body, maxLines = 4, fontSize = 13.sp)
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.deleteKnowledge(item.id); knowledge = api.knowledge() }
                                                catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                                            }
                                        }) { Text("Eintrag löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Was Neo gelernt hat", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Langfristige Vorlieben und Ziele. Du kannst alles einzeln entfernen.", color = Color.Gray)
                        Spacer(Modifier.height(16.dp))
                        if (memories.isEmpty()) Text("Noch keine Erinnerungen. Erzähle Neo etwas über deine Ziele.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(memories, key = { it.id }) { memory ->
                                Surface(shape = RoundedCornerShape(14.dp), color = Color.White) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(memory.content, Modifier.weight(1f))
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.forget(memory.id); memories = api.memories() }
                                                catch (e: Exception) { notice = e.message }
                                            }
                                        }) { Text("Löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Einstellungen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Cloudflare-Serveradresse (HTTPS)")
                        OutlinedTextField(value = urlDraft, onValueChange = { urlDraft = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("https://dein-server.de") }, singleLine = true)
                        OutlinedTextField(value = tokenDraft, onValueChange = { tokenDraft = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Neuer Zugangsschlüssel (wird verdeckt)") },
                            visualTransformation = PasswordVisualTransformation(), singleLine = true)
                        Text("Dein Schlüssel wird verschlüsselt im Android-Keystore gespeichert. Er erscheint nicht im Programmcode und darf nicht in Screenshots auftauchen.", fontSize = 12.sp, color = Color.Gray)
                        Button(onClick = {
                            val cleaned = urlDraft.trim().trimEnd('/')
                            if (!cleaned.startsWith("https://")) {
                                notice = "Bitte eine vollständige HTTPS-Adresse eingeben."
                            } else if (tokenDraft.isBlank() && token.isBlank()) {
                                notice = "Bitte den Zugangsschlüssel einfügen."
                            } else {
                                if (tokenDraft.isNotBlank()) {
                                    token = tokenDraft.trim()
                                    saveToken(token)
                                    tokenDraft = ""
                                }
                                url = cleaned
                                saveUrl(cleaned)
                                tab = 0
                                notice = "Verbindung gespeichert. Du kannst jetzt eine Frage stellen."
                            }
                        }) { Text("Server und Zugang speichern") }
                        HorizontalDivider()
                        Text("Persoenlichkeit und Eigeninitiative", fontWeight = FontWeight.SemiBold)
                        Text("Wie soll Neo KI mit dir sprechen? Die Wahl wird nur auf deinem Geraet gespeichert.",
                            fontSize = 12.sp, color = Color.Gray)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("natural" to "Natuerlich", "warm" to "Herzlich", "direct" to "Direkt").forEach { (style, label) ->
                                FilterChip(
                                    selected = chatStyle == style,
                                    onClick = { chatStyle = style; saveStyle(style) },
                                    label = { Text(label, fontSize = 12.sp) },
                                    enabled = !busy
                                )
                            }
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Leistungsstarkes KI-Modell (Llama 3.3 70B)")
                                Text("Mehr Qualitaet bei anspruchsvollen Fragen. Verbraucht mehr vom taeglichen kostenlosen Workers-AI-Kontingent. Kein automatisches Upgrade auf einen Bezahlplan.",
                                    fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(checked = smartMode, enabled = !busy,
                                onCheckedChange = { smartMode = it; saveSmart(it) })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Antwortpruefung (zusatzlicher KI-Aufruf)")
                                Text("Optional: Ein zweites, kleineres Modell sucht nach offensichtlichen Widerspruechen. Kein Faktenbeweis. Verbraucht zusaetzliches Cloudflare-Kontingent; standardmaessig aus.",
                                    fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(checked = qualityReview, enabled = !busy,
                                onCheckedChange = { qualityReview = it; saveReview(it) })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Sinnvolle eigene Vorschlaege")
                                Text("Neo darf passende Ideen anbieten, aber nichts ohne deinen Auftrag ausfuehren.",
                                    fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(checked = proactive, enabled = !busy,
                                onCheckedChange = { proactive = it; saveProactive(it) })
                        }
                        HorizontalDivider()
                        Text("Erwachsenenmodus (freiwillig, ab 18)", fontWeight = FontWeight.SemiBold)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (adultMode) "Erwachsenenmodus ist eingeschaltet" else "Erwachsenenmodus ist ausgeschaltet")
                                Text("Offene Gespraeche ueber erwachsene Sexualitaet, Erotik und Pornografie als Thema. " +
                                    "Explizite pornografische Texte und Bilder sind nicht garantiert; " +
                                    "die Regeln des KI-Modells bleiben bestehen.",
                                    fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(checked = adultMode, enabled = !adultChecking && !busy,
                                onCheckedChange = { enabled ->
                                    if (enabled) adultConfirm = true
                                    else { adultMode = false; saveAdult(false) }
                                })
                        }
                        if (adultChecking) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Nur der Chat-Gespraechsstil wird geaendert. Die Einstellung bleibt auf deinem Geraet. " +
                            "An den Server gehen der Modus (Ja/Nein) und die letzten Nachrichten derselben Sitzung und desselben Modus. " +
                            "Du kannst den Modus jederzeit abschalten.", fontSize = 12.sp, color = Color.Gray)
                        HorizontalDivider()
                        Text("Dazulernen: Nach Korrekturen macht Neo einen Lernvorschlag. Erst deine ausdrueckliche Bestaetigung speichert die Regel. Widerspruechliche Regeln zur Antwortlaenge werden zur Pruefung angehalten und nicht automatisch ersetzt. Kein Training der Modellgewichte.", fontSize = 12.sp, color = Color.Gray)
                        HorizontalDivider()
                        Text("Anhaenge: Einzelbilder werden verkleinert und zur Analyse an Cloudflare Workers AI geschickt. Bei PDF, TXT und MD wird nur ein Textauszug (max. 10.500 Zeichen) gesendet, nicht die Originaldatei. Keine automatische Speicherung von Anhaengen in D1. Diktat erfolgt ueber die auf deinem Geraet installierte Android-Spracherkennung; je nach Anbieter kann Sprachverarbeitung online stattfinden. Keine Hintergrundaufnahme.", fontSize = 12.sp, color = Color.Gray)
                        Text("Datenschutz", fontWeight = FontWeight.SemiBold)
                        Text("Notizen liegen in deiner Cloudflare-Datenbank. Fuer KI-Antworten werden sie an Cloudflare Workers AI uebermittelt. " +
                            "Der Chatverlauf bleibt lokal nur fuer die laufende App-Sitzung sichtbar. Bei einer Chatfrage " +
                            "werden passende letzte Nachrichten fuer den Kontext an den Cloudflare-Server und an Workers AI geschickt, " +
                            "aber nicht als Erinnerungen gespeichert. Mit 'Neuer Chat' entfernst du den lokalen Verlauf.", color = Color.DarkGray)
                        OutlinedButton(onClick = { confirmDelete = true }, enabled = url.isNotBlank() && token.isNotBlank() && !busy) {
                            Text("Alle Chats, Erinnerungen und Wissen löschen")
                        }
                        Text("Neo KI Cloud 0.9.10 · PDF/DOCX/TXT/MD + Bilder + Kamera + Diktat", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (lessonDialog) AlertDialog(
        onDismissRequest = { if (!lessonBusy) lessonDialog = false },
        title = { Text("Neo KI etwas beibringen") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Formuliere eine Korrektur oder Vorliebe. Ungepruefte Tatsachen sind kein sicheres Wissen. Widerspruechliche Antwortlaengen-Regeln muessen erst im Gedaechtnis geprueft werden. Keine Passwoerter eingeben.")
                OutlinedTextField(value = lessonDraft, onValueChange = { if (it.length <= 400) lessonDraft = it },
                    label = { Text("Lernregel (15–400 Zeichen)") }, minLines = 3, maxLines = 5,
                    enabled = !lessonBusy)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                lessonBusy = true
                val lesson = lessonDraft.trim()
                scope.launch {
                    try {
                        notice = api.saveLesson(lesson)
                        memories = api.memories()
                        messages = messages.map { item ->
                            if (item.learningSuggestion == lesson) item.copy(learningSuggestion = null) else item
                        }
                        lessonDialog = false
                        lessonDraft = ""
                    } catch (e: Exception) { notice = "Lernregel nicht gespeichert: ${e.message}" }
                    finally { lessonBusy = false }
                }
            }, enabled = !lessonBusy && lessonDraft.trim().length in 15..400) {
                Text(if (lessonBusy) "Speichert ..." else "Mit Zustimmung speichern")
            }
        },
        dismissButton = { TextButton(onClick = { lessonDialog = false }, enabled = !lessonBusy) { Text("Abbrechen") } }
    )
    if (adultConfirm) AlertDialog(
        onDismissRequest = { adultConfirm = false },
        title = { Text("Erwachsenenmodus aktivieren?") },
        text = { Text("Bestaetige bitte, dass du mindestens 18 Jahre alt bist und den offenen Gespraechsstil freiwillig einschalten moechtest. Der Modus aendert keine Sicherheitsregeln und nicht die Bilderstellung.") },
        confirmButton = {
            TextButton(onClick = {
                adultConfirm = false
                adultChecking = true
                scope.launch {
                    try {
                        if (!api.supportsAdultMode()) {
                            error("Bitte zuerst die aktuelle Neo-KI-Version bei Cloudflare bereitstellen.")
                        }
                        adultMode = true
                        saveAdult(true)
                        notice = "Erwachsenenmodus fuer den Chat aktiviert."
                    } catch (e: Exception) {
                        adultMode = false
                        saveAdult(false)
                        notice = "Aktivierung nicht moeglich: ${e.message}. Pruefe den Cloudflare-Code und deinen Zugang."
                    } finally { adultChecking = false }
                }
            }) { Text("Ich bin 18+ · Einschalten") }
        },
        dismissButton = { TextButton(onClick = { adultConfirm = false }) { Text("Abbrechen") } }
    )
    if (confirmClearChat) AlertDialog(
        onDismissRequest = { confirmClearChat = false },
        title = { Text("Neuen Chat beginnen?") },
        text = { Text("Die bisherigen Chatnachrichten werden auf diesem Geraet aus der aktuellen Sitzung entfernt. " +
            "Gespeicherte Erinnerungen, Bilder und Wissen bleiben erhalten.") },
        confirmButton = {
            TextButton(onClick = { messages = emptyList(); lessonDraft = ""; confirmClearChat = false }) {
                Text("Neuen Chat beginnen")
            }
        },
        dismissButton = { TextButton(onClick = { confirmClearChat = false }) { Text("Abbrechen") } }
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Alles löschen?") },
        text = { Text("Erinnerungen und Wissen werden aus der Cloudflare-Datenbank entfernt. Chatnachrichten werden nicht dauerhaft auf dem Server gespeichert. Sicherungskopien können bestehen bleiben.") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch {
                    try {
                        api.deleteAll()
                        messages = emptyList(); memories = emptyList(); knowledge = emptyList()
                        notice = "Daten wurden gelöscht."
                    } catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                }
            }) { Text("Ja, löschen") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Abbrechen") } }
    )
}
