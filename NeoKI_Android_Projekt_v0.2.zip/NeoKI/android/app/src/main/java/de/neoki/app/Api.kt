package de.neoki.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

data class WebSource(val title: String, val url: String)
data class ChatMessage(val role: String, val content: String, val sources: List<WebSource> = emptyList())
data class MemoryItem(val id: Int, val content: String)
data class KnowledgeItem(val id: Int, val title: String, val body: String)

class Api(private val baseUrl: String, private val deviceId: String) {
    private val base = baseUrl.trim().trimEnd('/')
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")

    private suspend fun request(method: String, path: String, payload: JSONObject? = null): JSONObject =
        withContext(Dispatchers.IO) {
            require(base.startsWith("https://") || base.startsWith("http://")) {
                "Bitte eine vollständige Serveradresse angeben"
            }
            val conn = URL("$base$path").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 15_000
                conn.readTimeout = 120_000
                conn.setRequestProperty("Accept", "application/json")
                if (payload != null) {
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                }
                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (status !in 200..299) {
                    val detail = runCatching { JSONObject(text).optString("detail") }.getOrNull()
                    error(detail?.takeIf { it.isNotBlank() } ?: "Serverfehler $status")
                }
                if (text.isBlank()) JSONObject() else JSONObject(text)
            } finally {
                conn.disconnect()
            }
        }

    suspend fun history(): List<ChatMessage> = parseMessages(
        request("GET", "/history?device_id=${enc(deviceId)}").getJSONArray("messages")
    )

    suspend fun chat(message: String, learn: Boolean, web: Boolean, work: Boolean): List<ChatMessage> {
        val body = JSONObject().put("device_id", deviceId).put("message", message)
            .put("auto_learn", learn).put("use_web", web).put("work_mode", work)
        return parseMessages(request("POST", "/chat", body).getJSONArray("messages"))
    }

    suspend fun memories(): List<MemoryItem> {
        val array = request("GET", "/memories?device_id=${enc(deviceId)}").getJSONArray("memories")
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            MemoryItem(item.getInt("id"), item.getString("content"))
        }
    }

    suspend fun forget(id: Int) { request("DELETE", "/memories/$id?device_id=${enc(deviceId)}") }

    suspend fun knowledge(): List<KnowledgeItem> {
        val array = request("GET", "/knowledge?device_id=${enc(deviceId)}").getJSONArray("knowledge")
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            KnowledgeItem(item.getInt("id"), item.getString("title"), item.getString("body"))
        }
    }

    suspend fun addKnowledge(title: String, body: String) {
        request("POST", "/knowledge", JSONObject().put("device_id", deviceId)
            .put("title", title).put("body", body))
    }

    suspend fun deleteKnowledge(id: Int) { request("DELETE", "/knowledge/$id?device_id=${enc(deviceId)}") }
    suspend fun deleteAll() { request("DELETE", "/data?device_id=${enc(deviceId)}") }

    private fun parseMessages(array: JSONArray): List<ChatMessage> = (0 until array.length()).map { i ->
        val item = array.getJSONObject(i)
        val src = item.optJSONArray("sources") ?: JSONArray()
        ChatMessage(item.getString("role"), item.getString("content"), (0 until src.length()).map { j ->
            val s = src.getJSONObject(j)
            WebSource(s.optString("title", s.getString("url")), s.getString("url"))
        })
    }
}
