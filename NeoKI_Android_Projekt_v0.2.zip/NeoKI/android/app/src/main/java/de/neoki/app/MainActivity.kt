package de.neoki.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

private val dark = Color(0xFF11172B)
private val teal = Color(0xFF079F8A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("neo_prefs", MODE_PRIVATE)
        val deviceId = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("device_id", it).apply()
        }
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = dark, secondary = teal)) {
                NeoScreen(
                    id = deviceId,
                    initialUrl = prefs.getString("server_url", "") ?: "",
                    initialLearn = prefs.getBoolean("auto_learn", true),
                    initialWeb = prefs.getBoolean("use_web", false),
                    initialWork = prefs.getBoolean("work_mode", false),
                    saveUrl = { prefs.edit().putString("server_url", it).apply() },
                    saveLearn = { prefs.edit().putBoolean("auto_learn", it).apply() },
                    saveWeb = { prefs.edit().putBoolean("use_web", it).apply() },
                    saveWork = { prefs.edit().putBoolean("work_mode", it).apply() }
                )
            }
        }
    }
}

@Composable
fun NeoScreen(
    id: String, initialUrl: String, initialLearn: Boolean, initialWeb: Boolean, initialWork: Boolean,
    saveUrl: (String) -> Unit, saveLearn: (Boolean) -> Unit,
    saveWeb: (Boolean) -> Unit, saveWork: (Boolean) -> Unit
) {
    var url by remember { mutableStateOf(initialUrl) }
    var urlDraft by remember { mutableStateOf(initialUrl) }
    var learn by remember { mutableStateOf(initialLearn) }
    var useWeb by remember { mutableStateOf(initialWeb) }
    var work by remember { mutableStateOf(initialWork) }
    var tab by remember { mutableIntStateOf(if (initialUrl.isBlank()) 3 else 0) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var memories by remember { mutableStateOf<List<MemoryItem>>(emptyList()) }
    var knowledge by remember { mutableStateOf<List<KnowledgeItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var knowledgeTitle by remember { mutableStateOf("") }
    var knowledgeBody by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val api = remember(url, id) { Api(url, id) }
    val uriHandler = LocalUriHandler.current

    fun reload() {
        if (url.isBlank()) return
        scope.launch {
            try {
                messages = api.history()
                memories = api.memories()
                knowledge = api.knowledge()
                notice = null
            } catch (e: Exception) {
                notice = "Verbindung fehlgeschlagen: ${e.message}"
            }
        }
    }

    LaunchedEffect(url) { if (url.isNotBlank()) reload() }

    fun send() {
        val text = input.trim()
        if (text.isBlank() || busy || url.isBlank()) return
        input = ""
        busy = true
        notice = null
        messages = messages + ChatMessage("user", text)
        scope.launch {
            try {
                messages = api.chat(text, learn, useWeb, work)
                memories = api.memories()
            } catch (e: Exception) {
                notice = "Antwort fehlgeschlagen: ${e.message}"
                messages = messages.dropLast(1)
                input = text
            } finally { busy = false }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF6F8FC),
        topBar = {
            Row(Modifier.fillMaxWidth().background(dark).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEO KI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Chat · Internet · Wissen · Arbeitsmodus", color = Color(0xFFC7D4ED), fontSize = 12.sp)
                }
                Text(if (url.isBlank()) "Offline" else "Server gesetzt", color = Color(0xFF8CF3D8), fontSize = 12.sp)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Chat", "Wissen", "Gedächtnis", "Setup").forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index; notice = null; if (index in 1..2) reload() },
                        icon = { Text(listOf("✦", "▤", "♡", "⚙")[index], fontSize = 22.sp) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (notice != null) {
                Surface(color = Color(0xFFFFEBE5)) {
                    Text(notice ?: "", Modifier.fillMaxWidth().padding(12.dp), color = Color(0xFF922D1B))
                }
            }
            when (tab) {
                0 -> {
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("🌐 Internet", fontSize = 12.sp)
                        Switch(checked = useWeb, onCheckedChange = { useWeb = it; saveWeb(it) })
                        Text("🛠 Arbeiten", fontSize = 12.sp)
                        Switch(checked = work, onCheckedChange = { work = it; saveWork(it) })
                    }
                    if (useWeb) {
                        Text("Websuche kann zusätzliche API-Kosten verursachen.",
                            Modifier.padding(horizontal = 12.dp, vertical = 2.dp), fontSize = 11.sp, color = Color.Gray)
                    }
                    val state = rememberLazyListState()
                    LaunchedEffect(messages.size, busy) {
                        if (messages.isNotEmpty()) state.animateScrollToItem(messages.lastIndex)
                    }
                    LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (messages.isEmpty()) item {
                            Column(Modifier.fillMaxWidth().padding(top = 58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("✦", fontSize = 50.sp, color = teal)
                                Text("Hallo! Ich bin Neo.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Ich recherchiere im Internet, beantworte Fragen und nutze deine Wissensdatenbank.",
                                    textAlign = TextAlign.Center, color = Color.DarkGray)
                                if (url.isBlank()) {
                                    Spacer(Modifier.height(20.dp))
                                    Button(onClick = { tab = 3 }) { Text("Server verbinden") }
                                }
                            }
                        }
                        items(messages) { message ->
                            val isUser = message.role == "user"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                                Surface(modifier = Modifier.fillMaxWidth(0.92f),
                                    color = if (isUser) dark else Color.White,
                                    shape = RoundedCornerShape(16.dp), shadowElevation = if (isUser) 0.dp else 2.dp) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(message.content, color = if (isUser) Color.White else dark, fontSize = 15.sp)
                                        if (!isUser && message.sources.isNotEmpty()) {
                                            Spacer(Modifier.height(8.dp))
                                            Text("Internetquellen:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            message.sources.forEach { source ->
                                                TextButton(onClick = {
                                                    if (source.url.startsWith("https://") || source.url.startsWith("http://"))
                                                        uriHandler.openUri(source.url)
                                                }) { Text(source.title, maxLines = 2, fontSize = 12.sp) }
                                            }
                                        }
                                        if (!isUser) {
                                            TextButton(onClick = {
                                                scope.launch {
                                                    try {
                                                        api.addKnowledge("Gespeicherte KI-Antwort", message.content.take(8000))
                                                        knowledge = api.knowledge()
                                                        notice = "Antwort als Wissenseintrag gespeichert. Bitte Fakten prüfen."
                                                    } catch (e: Exception) { notice = "Speichern fehlgeschlagen: ${e.message}" }
                                                }
                                            }, enabled = url.isNotBlank()) { Text("Ins Wissen übernehmen", fontSize = 12.sp) }
                                        }
                                    }
                                }
                            }
                        }
                        if (busy) item { Text("Neo bearbeitet deine Anfrage …", color = Color.Gray) }
                    }
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(value = input, onValueChange = { if (it.length <= 3000) input = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("Frage oder Arbeitsauftrag …") },
                            maxLines = 4, enabled = !busy,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { send() }))
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { send() }, enabled = !busy && input.isNotBlank() && url.isNotBlank(),
                            contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Senden") }
                    }
                }
                1 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Deine Wissensdatenbank", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Eigene Daten speichern oder KI-Antworten aus dem Chat übernehmen. Neo nutzt passende Einträge.",
                            fontSize = 12.sp, color = Color.Gray)
                        OutlinedTextField(value = knowledgeTitle, onValueChange = { if (it.length <= 120) knowledgeTitle = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Titel / Thema") }, singleLine = true)
                        OutlinedTextField(value = knowledgeBody, onValueChange = { if (it.length <= 8000) knowledgeBody = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp), label = { Text("Wissen / Notizen / Daten") }, maxLines = 5)
                        Button(onClick = {
                            scope.launch {
                                try {
                                    api.addKnowledge(knowledgeTitle.trim(), knowledgeBody.trim())
                                    knowledgeTitle = ""; knowledgeBody = ""; knowledge = api.knowledge()
                                    notice = "Wissenseintrag gespeichert."
                                } catch (e: Exception) { notice = "Fehler: ${e.message}" }
                            }
                        }, enabled = url.isNotBlank() && knowledgeTitle.isNotBlank() && knowledgeBody.isNotBlank()) {
                            Text("Wissen speichern")
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(knowledge, key = { it.id }) { item ->
                                Surface(shape = RoundedCornerShape(12.dp), color = Color.White) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text(item.body, maxLines = 4, fontSize = 13.sp)
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.deleteKnowledge(item.id); knowledge = api.knowledge() }
                                                catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                                            }
                                        }) { Text("Eintrag löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Was Neo gelernt hat", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Langfristige Vorlieben und Ziele. Du kannst alles einzeln entfernen.", color = Color.Gray)
                        Spacer(Modifier.height(16.dp))
                        if (memories.isEmpty()) Text("Noch keine Erinnerungen. Erzähle Neo etwas über deine Ziele.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(memories, key = { it.id }) { memory ->
                                Surface(shape = RoundedCornerShape(14.dp), color = Color.White) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(memory.content, Modifier.weight(1f))
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.forget(memory.id); memories = api.memories() }
                                                catch (e: Exception) { notice = e.message }
                                            }
                                        }) { Text("Löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Einstellungen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Adresse deines KI-Servers")
                        OutlinedTextField(value = urlDraft, onValueChange = { urlDraft = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("https://dein-server.de") }, singleLine = true)
                        Button(onClick = {
                            val cleaned = urlDraft.trim().trimEnd('/')
                            if (cleaned.startsWith("https://") || cleaned.startsWith("http://")) {
                                url = cleaned; saveUrl(cleaned); tab = 0; notice = null
                            } else notice = "Bitte eine vollständige http(s)-Adresse eingeben."
                        }) { Text("Server speichern") }
                        HorizontalDivider()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Automatisch dazulernen", fontWeight = FontWeight.SemiBold)
                                Text("Speichert Vorlieben und Ziele, kein neues KI-Modell.", fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(checked = learn, onCheckedChange = { learn = it; saveLearn(it) })
                        }
                        HorizontalDivider()
                        Text("Datenschutz", fontWeight = FontWeight.SemiBold)
                        Text("Chats, persönliche Erinnerungen und Wissen liegen auf deinem Server und gehen für Antworten an den KI-Anbieter. Websuche kann Inhalte an einen Suchdienst senden.", color = Color.DarkGray)
                        OutlinedButton(onClick = { confirmDelete = true }, enabled = url.isNotBlank() && !busy) {
                            Text("Alle Chats, Erinnerungen und Wissen löschen")
                        }
                        Text("Neo KI 0.2 · Privater Android-Prototyp", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Alles löschen?") },
        text = { Text("Chats, Erinnerungen und Wissensdatenbank werden vom Server gelöscht. Sicherungskopien bleiben eventuell erhalten.") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch {
                    try {
                        api.deleteAll()
                        messages = emptyList(); memories = emptyList(); knowledge = emptyList()
                        notice = "Daten wurden gelöscht."
                    } catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                }
            }) { Text("Ja, löschen") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Abbrechen") } }
    )
}
