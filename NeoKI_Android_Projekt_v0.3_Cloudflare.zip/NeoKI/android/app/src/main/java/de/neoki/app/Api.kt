package de.neoki.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

data class WebSource(val title: String, val url: String)
data class ChatMessage(val role: String, val content: String, val sources: List<WebSource> = emptyList())
data class MemoryItem(val id: Int, val content: String)
data class KnowledgeItem(val id: Int, val title: String, val body: String)

/** Client for the user's Cloudflare Worker v0.3; token is provided at runtime, never embedded. */
class Api(private val baseUrl: String, private val token: String) {
    private val base = baseUrl.trim().trimEnd('/')
    private suspend fun request(method: String, path: String, payload: JSONObject? = null): JSONObject =
        withContext(Dispatchers.IO) {
            require(base.startsWith("https://")) { "Bitte eine HTTPS-Serveradresse angeben" }
            require(token.isNotBlank()) { "Bitte im Setup den Zugangsschlüssel speichern" }
            val conn = URL("$base$path").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = method
                conn.connectTimeout = 15_000
                conn.readTimeout = 120_000
                conn.setRequestProperty("Accept", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $token")
                if (payload != null) {
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                }
                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (status !in 200..299) {
                    val detail = runCatching {
                        JSONObject(body).let { it.optString("error").ifBlank { it.optString("detail") } }
                    }.getOrNull()
                    error(detail?.takeIf { it.isNotBlank() } ?: "Serverfehler $status")
                }
                if (body.isBlank()) JSONObject() else JSONObject(body)
            } finally { conn.disconnect() }
        }

    suspend fun chat(message: String): String =
        request("POST", "/chat", JSONObject().put("message", message)).optString("answer", "Keine Antwort")

    private suspend fun allNotes(): List<MemoryItem> {
        val array = request("GET", "/memories").getJSONArray("memories")
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            MemoryItem(item.getInt("id"), item.getString("content"))
        }
    }

    suspend fun memories(): List<MemoryItem> = allNotes().filterNot { it.content.startsWith("Wissen: ") }
    suspend fun forget(id: Int) { request("DELETE", "/memories/$id") }

    suspend fun knowledge(): List<KnowledgeItem> = allNotes().filter { it.content.startsWith("Wissen: ") }.map {
        val parts = it.content.removePrefix("Wissen: ").split("\n", limit = 2)
        KnowledgeItem(it.id, parts.firstOrNull().orEmpty(), parts.getOrElse(1) { "" })
    }

    suspend fun addKnowledge(title: String, body: String) {
        require(title.isNotBlank() && body.isNotBlank()) { "Titel und Text fehlen" }
        val full = "Wissen: ${title.trim()}\n${body.trim()}"
        require(full.length <= 2000) { "Wissenseintrag darf höchstens 2000 Zeichen haben" }
        request("POST", "/memories", JSONObject().put("content", full))
    }
    suspend fun deleteKnowledge(id: Int) { forget(id) }
    suspend fun deleteAll() {
        while (true) {
            val batch = allNotes()
            if (batch.isEmpty()) break
            batch.forEach { forget(it.id) }
            if (batch.size < 100) break
        }
    }
}
