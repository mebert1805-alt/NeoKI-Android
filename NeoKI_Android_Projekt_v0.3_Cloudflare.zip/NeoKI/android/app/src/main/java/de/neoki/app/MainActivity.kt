package de.neoki.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

private val dark = Color(0xFF11172B)
private val teal = Color(0xFF079F8A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("neo_prefs", MODE_PRIVATE)
        val deviceId = prefs.getString("device_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("device_id", it).apply()
        }
        val secretStore = SecretStore(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = dark, secondary = teal)) {
                NeoScreen(
                    id = deviceId,
                    initialUrl = prefs.getString("server_url", "https://neoki-gedaechtnis-test.mebert1805.workers.dev") ?: "",
                    initialToken = secretStore.read(),
                    initialLearn = prefs.getBoolean("auto_learn", true),
                    initialWeb = prefs.getBoolean("use_web", false),
                    initialWork = prefs.getBoolean("work_mode", false),
                    saveUrl = { prefs.edit().putString("server_url", it).apply() },
                    saveToken = { secretStore.save(it) },
                    saveLearn = { prefs.edit().putBoolean("auto_learn", it).apply() },
                    saveWeb = { prefs.edit().putBoolean("use_web", it).apply() },
                    saveWork = { prefs.edit().putBoolean("work_mode", it).apply() }
                )
            }
        }
    }
}

@Composable
fun NeoScreen(
    id: String, initialUrl: String, initialToken: String, initialLearn: Boolean, initialWeb: Boolean, initialWork: Boolean,
    saveUrl: (String) -> Unit, saveToken: (String) -> Unit, saveLearn: (Boolean) -> Unit,
    saveWeb: (Boolean) -> Unit, saveWork: (Boolean) -> Unit
) {
    var url by remember { mutableStateOf(initialUrl) }
    var urlDraft by remember { mutableStateOf(initialUrl) }
    var token by remember { mutableStateOf(initialToken) }
    var tokenDraft by remember { mutableStateOf("") }
    var learn by remember { mutableStateOf(initialLearn) }
    var useWeb by remember { mutableStateOf(initialWeb) }
    var work by remember { mutableStateOf(initialWork) }
    var tab by remember { mutableIntStateOf(if (initialUrl.isBlank() || initialToken.isBlank()) 3 else 0) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var memories by remember { mutableStateOf<List<MemoryItem>>(emptyList()) }
    var knowledge by remember { mutableStateOf<List<KnowledgeItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var knowledgeTitle by remember { mutableStateOf("") }
    var knowledgeBody by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val api = remember(url, token) { Api(url, token) }
    val uriHandler = LocalUriHandler.current

    fun reload() {
        if (url.isBlank() || token.isBlank()) return
        scope.launch {
            try {
                memories = api.memories()
                knowledge = api.knowledge()
                notice = null
            } catch (e: Exception) {
                notice = "Verbindung fehlgeschlagen: ${e.message}"
            }
        }
    }

    LaunchedEffect(url, token) { if (url.isNotBlank() && token.isNotBlank()) reload() }

    fun send() {
        val text = input.trim()
        if (text.isBlank() || busy || url.isBlank() || token.isBlank()) return
        input = ""
        busy = true
        notice = null
        messages = messages + ChatMessage("user", text)
        scope.launch {
            try {
                messages = messages + ChatMessage("assistant", api.chat(text))
                memories = api.memories()
            } catch (e: Exception) {
                notice = "Antwort fehlgeschlagen: ${e.message}"
                messages = messages.dropLast(1)
                input = text
            } finally { busy = false }
        }
    }

    Scaffold(
        containerColor = Color(0xFFF6F8FC),
        topBar = {
            Row(Modifier.fillMaxWidth().background(dark).padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEO KI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Chat · Gedächtnis · Wissen", color = Color(0xFFC7D4ED), fontSize = 12.sp)
                }
                Text(if (url.isBlank() || token.isBlank()) "Setup fehlt" else "Zugang gespeichert", color = Color(0xFF8CF3D8), fontSize = 12.sp)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Chat", "Wissen", "Gedächtnis", "Setup").forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index; notice = null; if (index in 1..2) reload() },
                        icon = { Text(listOf("✦", "▤", "♡", "⚙")[index], fontSize = 22.sp) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (notice != null) {
                Surface(color = Color(0xFFFFEBE5)) {
                    Text(notice ?: "", Modifier.fillMaxWidth().padding(12.dp), color = Color(0xFF922D1B))
                }
            }
            when (tab) {
                0 -> {
                    Text("Cloudflare-KI ist verbunden, sobald du den Zugang eingerichtet hast. Internetrecherche und automatische Aktionen folgen später.",
                        Modifier.fillMaxWidth().background(Color.White).padding(12.dp), fontSize = 12.sp, color = Color.Gray)
                    val state = rememberLazyListState()
                    LaunchedEffect(messages.size, busy) {
                        if (messages.isNotEmpty()) state.animateScrollToItem(messages.lastIndex)
                    }
                    LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (messages.isEmpty()) item {
                            Column(Modifier.fillMaxWidth().padding(top = 58.dp),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("✦", fontSize = 50.sp, color = teal)
                                Text("Hallo! Ich bin Neo.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Ich beantworte Fragen und verwende deine gespeicherten Erinnerungen und Wissensnotizen.",
                                    textAlign = TextAlign.Center, color = Color.DarkGray)
                                if (url.isBlank() || token.isBlank()) {
                                    Spacer(Modifier.height(20.dp))
                                    Button(onClick = { tab = 3 }) { Text("Server verbinden") }
                                }
                            }
                        }
                        items(messages) { message ->
                            val isUser = message.role == "user"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                                Surface(modifier = Modifier.fillMaxWidth(0.92f),
                                    color = if (isUser) dark else Color.White,
                                    shape = RoundedCornerShape(16.dp), shadowElevation = if (isUser) 0.dp else 2.dp) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(message.content, color = if (isUser) Color.White else dark, fontSize = 15.sp)
                                        if (!isUser && message.sources.isNotEmpty()) {
                                            Spacer(Modifier.height(8.dp))
                                            Text("Internetquellen:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            message.sources.forEach { source ->
                                                TextButton(onClick = {
                                                    if (source.url.startsWith("https://") || source.url.startsWith("http://"))
                                                        uriHandler.openUri(source.url)
                                                }) { Text(source.title, maxLines = 2, fontSize = 12.sp) }
                                            }
                                        }
                                        if (!isUser) {
                                            TextButton(onClick = {
                                                scope.launch {
                                                    try {
                                                        api.addKnowledge("Gespeicherte KI-Antwort", message.content.take(8000))
                                                        knowledge = api.knowledge()
                                                        notice = "Antwort als Wissenseintrag gespeichert. Bitte Fakten prüfen."
                                                    } catch (e: Exception) { notice = "Speichern fehlgeschlagen: ${e.message}" }
                                                }
                                            }, enabled = url.isNotBlank() && token.isNotBlank()) { Text("Ins Wissen übernehmen", fontSize = 12.sp) }
                                        }
                                    }
                                }
                            }
                        }
                        if (busy) item { Text("Neo bearbeitet deine Anfrage …", color = Color.Gray) }
                    }
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(value = input, onValueChange = { if (it.length <= 3000) input = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("Frage oder Arbeitsauftrag …") },
                            maxLines = 4, enabled = !busy,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { send() }))
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { send() }, enabled = !busy && input.isNotBlank() && url.isNotBlank(),
                            contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Senden") }
                    }
                }
                1 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Deine Wissensdatenbank", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Eigene Daten speichern oder KI-Antworten aus dem Chat übernehmen. Neo nutzt passende Einträge.",
                            fontSize = 12.sp, color = Color.Gray)
                        OutlinedTextField(value = knowledgeTitle, onValueChange = { if (it.length <= 120) knowledgeTitle = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Titel / Thema") }, singleLine = true)
                        OutlinedTextField(value = knowledgeBody, onValueChange = { if (it.length <= 1700) knowledgeBody = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp), label = { Text("Wissen / Notizen (max. 1700 Zeichen)") }, maxLines = 5)
                        Button(onClick = {
                            scope.launch {
                                try {
                                    api.addKnowledge(knowledgeTitle.trim(), knowledgeBody.trim())
                                    knowledgeTitle = ""; knowledgeBody = ""; knowledge = api.knowledge()
                                    notice = "Wissenseintrag gespeichert."
                                } catch (e: Exception) { notice = "Fehler: ${e.message}" }
                            }
                        }, enabled = url.isNotBlank() && token.isNotBlank() && knowledgeTitle.isNotBlank() && knowledgeBody.isNotBlank()) {
                            Text("Wissen speichern")
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(knowledge, key = { it.id }) { item ->
                                Surface(shape = RoundedCornerShape(12.dp), color = Color.White) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text(item.title, fontWeight = FontWeight.Bold)
                                        Text(item.body, maxLines = 4, fontSize = 13.sp)
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.deleteKnowledge(item.id); knowledge = api.knowledge() }
                                                catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                                            }
                                        }) { Text("Eintrag löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("Was Neo gelernt hat", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Langfristige Vorlieben und Ziele. Du kannst alles einzeln entfernen.", color = Color.Gray)
                        Spacer(Modifier.height(16.dp))
                        if (memories.isEmpty()) Text("Noch keine Erinnerungen. Erzähle Neo etwas über deine Ziele.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(memories, key = { it.id }) { memory ->
                                Surface(shape = RoundedCornerShape(14.dp), color = Color.White) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(memory.content, Modifier.weight(1f))
                                        TextButton(onClick = {
                                            scope.launch {
                                                try { api.forget(memory.id); memories = api.memories() }
                                                catch (e: Exception) { notice = e.message }
                                            }
                                        }) { Text("Löschen") }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Einstellungen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Cloudflare-Serveradresse (HTTPS)")
                        OutlinedTextField(value = urlDraft, onValueChange = { urlDraft = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("https://dein-server.de") }, singleLine = true)
                        OutlinedTextField(value = tokenDraft, onValueChange = { tokenDraft = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Neuer Zugangsschlüssel (wird verdeckt)") },
                            visualTransformation = PasswordVisualTransformation(), singleLine = true)
                        Text("Dein Schlüssel wird verschlüsselt im Android-Keystore gespeichert. Er erscheint nicht im Programmcode und darf nicht in Screenshots auftauchen.", fontSize = 12.sp, color = Color.Gray)
                        Button(onClick = {
                            val cleaned = urlDraft.trim().trimEnd('/')
                            if (!cleaned.startsWith("https://")) {
                                notice = "Bitte eine vollständige HTTPS-Adresse eingeben."
                            } else if (tokenDraft.isBlank() && token.isBlank()) {
                                notice = "Bitte den Zugangsschlüssel einfügen."
                            } else {
                                if (tokenDraft.isNotBlank()) {
                                    token = tokenDraft.trim()
                                    saveToken(token)
                                    tokenDraft = ""
                                }
                                url = cleaned
                                saveUrl(cleaned)
                                tab = 0
                                notice = "Verbindung gespeichert. Du kannst jetzt eine Frage stellen."
                            }
                        }) { Text("Server und Zugang speichern") }
                        HorizontalDivider()
                        Text("Gedächtnis: Eigene Notizen können gespeichert und in KI-Antworten verwendet werden. Neo trainiert das KI-Modell nicht automatisch neu.", fontSize = 12.sp, color = Color.Gray)
                        HorizontalDivider()
                        Text("Datenschutz", fontWeight = FontWeight.SemiBold)
                        Text("Notizen liegen in deiner Cloudflare-Datenbank. Für KI-Antworten werden sie an Cloudflare Workers AI übermittelt. Chatnachrichten bleiben derzeit nur während der geöffneten App-Sitzung sichtbar.", color = Color.DarkGray)
                        OutlinedButton(onClick = { confirmDelete = true }, enabled = url.isNotBlank() && token.isNotBlank() && !busy) {
                            Text("Alle Chats, Erinnerungen und Wissen löschen")
                        }
                        Text("Neo KI Cloud 0.3 · Privater Android-Prototyp", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Alles löschen?") },
        text = { Text("Erinnerungen und Wissen werden aus der Cloudflare-Datenbank entfernt. Chatnachrichten werden nicht dauerhaft auf dem Server gespeichert. Sicherungskopien können bestehen bleiben.") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                scope.launch {
                    try {
                        api.deleteAll()
                        messages = emptyList(); memories = emptyList(); knowledge = emptyList()
                        notice = "Daten wurden gelöscht."
                    } catch (e: Exception) { notice = "Löschen fehlgeschlagen: ${e.message}" }
                }
            }) { Text("Ja, löschen") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Abbrechen") } }
    )
}
