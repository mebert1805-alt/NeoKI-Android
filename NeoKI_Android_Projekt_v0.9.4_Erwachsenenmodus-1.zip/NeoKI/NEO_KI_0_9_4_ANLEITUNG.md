# Neo KI 0.9.4 – Bildstudio und freiwilliger Erwachsenenmodus

## Zuerst Cloudflare aktualisieren

1. Den bisher funktionierenden `worker.js`-Code **sichern**.
2. Gesamte Datei `NeoKI_0.9.4_Cloudflare_Code.txt` in Cloudflares `worker.js` einfügen.
3. Kontrollieren, ob der Editor 0 Fehler meldet, und **Bereitstellen** klicken.
4. Keine weiteren Secrets und keine weiteren Tabellen nötig. `AI`, `DB` und `NEOKI_ACCESS_TOKEN` bleiben unverändert.
5. Optional `.../health` öffnen: `version` ist `0.9.4`. Der Endpunkt `/capabilities` erfordert den bisherigen Zugangsschlüssel und lässt sich nicht einfach ohne diesen im Browser aufrufen.

## Danach Android 0.9.4 installieren

1. ZIP `NeoKI_Android_Projekt_v0.9.4_Erwachsenenmodus.zip` im GitHub-Repository `mebert1805-alt/NeoKI-Android` im Root hochladen, ohne zu entpacken.
2. Unter `.github/workflows/android-apk.yml` in der Zeile `run: unzip -q ... -d projekt` den Dateinamen **genau auf den tatsächlichen GitHub-Dateinamen** setzen. GitHub benennt gelegentlich in `-1.zip` um.
3. `Commit changes` – GitHub Actions startet normalerweise den APK-Bau.
4. Nach grüner Erfolgsmeldung unter `Artifacts` auf `NeoKI-APK` klicken, ZIP entpacken, `app-debug.apk` installieren.
5. Android 0.9.4 ist als eigene Test-App installiert (`de.neoki.app.cloud.adultmode`); die vorherigen Apps bleiben unangetastet. Unter `Setup` einmal deine Cloudflare-Adresse und deinen vorhandenen Schlüssel eintragen. Den Zugangsschlüssel **nirgends veröffentlichen**.
6. Im Setup weiter nach unten zu `Erwachsenenmodus (freiwillig, ab 18)` scrollen. Schalter aktivieren, Volljährigkeit bestätigen. Die App prüft bei deinem Worker `/capabilities`, ob die 0.9.4-Version installiert ist.
7. Chat testen; oben steht `Erwachsenenmodus aktiv`, solange er eingeschaltet ist. Zum Abschalten Schalter im Setup wieder ausschalten.

## Technische Grenzen

- Nur der normale Chat nutzt den alternativen Gesprächsstil. Wetter, Arbeit, Quellenrecherche, Gedächtnis und Bildgenerierung bleiben unverändert.
- Keine erotische Bildgenerierung freigeschaltet und keine Sicherheitsfilter deaktiviert. Was das Sprachmodell tatsächlich beantworten kann, ist durch dessen Regeln und Fähigkeiten begrenzt.
- Die Einstellung ist standardmäßig aus. Lokal speichert die App nur `true`/`false`, keine Altersdaten.
- Ein App-Klick allein genügt nicht: **Cloudflare muss zuerst 0.9.4 ausführen**, sonst kann der Modus nicht aktiviert werden.
- Der Android-Quellcode enthält keinen Zugangsschlüssel. Der vorhandene Zugang wird wie bisher per Android Keystore verschlüsselt gespeichert.
- Dies ist ein Debug-/Test-Build; nicht ungeprüft im Play Store veröffentlichen.
