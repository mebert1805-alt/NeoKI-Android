# Neo KI 0.9.5 – Mehr Persönlichkeit und Gesprächskontext

## Was neu ist
- Natürlicherer Antwortstil mit kurzen, direkten Antworten statt Standardfloskeln.
- Die App schickt bei einer normalen Chatfrage bis zu 8 letzte Beiträge **derselben App-Sitzung und desselben Gesprächsmodus** als Kontext mit.
- Die Kontextdaten sind auf 3.800 Zeichen begrenzt; auf dem Server werden sie nicht automatisch in D1 gespeichert.
- Keine automatische Speicherung privater Chatnachrichten. Das bestehende Gedächtnis speichert weiterhin nur auf ausdrücklichen Befehl.
- **Neuer Chat** löscht den sichtbaren Sitzungsverlauf aus der App, nicht die gespeicherten Erinnerungen.
- Beim Umschalten des Erwachsenenmodus wird der vorherige Modus **nicht als KI-Kontext mitgesendet**.
- Bildgenerator, Recherche, Gedächtnis, freiwilliger Erwachsenenmodus bleiben erhalten.

## 1. Cloudflare (zuerst)
1. Funktionierenden `worker.js`-Code von 0.9.4 sichern.
2. Vollständigen Inhalt von `NeoKI_0.9.5_Cloudflare_Code.txt` im Cloudflare-Worker `neoki-gedaechtnis-test` einsetzen.
3. Auf 0 Fehler prüfen und **Bereitstellen** klicken.
4. Keine Datenbankänderung, keine neuen Secrets nötig.

## 2. Android über GitHub Actions
1. ZIP `NeoKI_Android_Projekt_v0.9.5_Persoenlichkeit.zip` ohne Entpacken ins Repo `mebert1805-alt/NeoKI-Android` hochladen.
2. In `.github/workflows/android-apk.yml` bei `Projekt entpacken` den dort tatsächlich angezeigten ZIP-Dateinamen einsetzen:

   `run: unzip -q NeoKI_Android_Projekt_v0.9.5_Persoenlichkeit.zip -d projekt`

   GitHub kann bei doppeltem Upload `-1` vor `.zip` ergänzen. **Genauen Namen auf GitHub prüfen.**
3. Commit changes drücken und unter Actions den Build abwarten.
4. Bei erfolgreichem Build das Artifact `NeoKI-APK` downloaden, entpacken und `app-debug.apk` installieren.

**Diese 0.9.5-Test-App ist separat installierbar**, damit die bisher funktionierende 0.9.4 auf dem Handy bleiben kann. Serveradresse und Zugangsschlüssel müssen in der Test-App erneut eingegeben werden. Geheimen Schlüssel niemals teilen.

## 3. Tests
- Normaler Chat: `Ich lerne gerade Gitarre.` danach `Was lerne ich gerade?` sollte auf Gitarre Bezug nehmen, **ohne** dass ein D1-Merkbefehl verwendet wurde.
- Prüfen: In neuer Sitzung oder mit `Neuer Chat` sollte die Information nicht automatisch als Langzeitgedächtnis gelten.
- Erwachsenenmodus ein-/ausschalten: Der Verlauf des jeweils anderen Modus wird nicht mitgeschickt.
- Bilder erzeugen und speichern; normale Gedächtnisabfrage prüfen.

## Grenzen
Lokaler Syntax- und API-Mocktest sind keine Live-Cloudflare- oder Android-Kompilierung. KI-Ergebnisse können weiterhin Fehler enthalten. Dies ist kein autonomer Hintergrundagent. Die eigentliche Modellintelligenz bleibt vom gewählten Cloudflare-Modell und dem kostenlosen Kontingent abhängig.
