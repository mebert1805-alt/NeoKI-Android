# Neo KI 0.9.6 – Persönlichkeit, Eigeninitiative und Erwachsenengespräche

## Neuerungen
- Drei frei wählbare Gesprächsstile: Natürlich, Herzlich, Direkt (in Setup).
- Eigene Vorschläge lassen sich ein- oder ausschalten; der Schalter löst keine eigenständigen externen Aktionen aus.
- Verwendet weiterhin maximal acht vorherige Chatnachrichten derselben App-Sitzung und desselben Erwachsenenmodus.
- Erwachsenengespräche: Offenheit für Sexualität, Intimität und Diskussion über Pornografie. **Keine Zusage einer uneingeschränkten pornografischen Text- oder Bildgenerierung**. Die Sicherheitsregeln des Cloudflare-Modells gelten weiterhin. Bildgenerierung wird vom Erwachsenenmodus nicht verändert.
- Keine neuen Datenbanktabellen; kein neuer Zugangsschlüssel. Gedächtnis, Recherchen, Bilder und Wissensbereich bleiben erhalten.
- App als separate Testinstallation (0.9.5 bleibt installierbar). Bestehende Einstellungen und der Zugangsschlüssel der separaten App müssen einmalig neu eingegeben werden.

## 1. Cloudflare
1. Sicherung der funktionierenden `worker.js`-Version 0.9.5 erstellen.
2. Den gesamten Inhalt von `NeoKI_0.9.6_Cloudflare_Code.txt` als `worker.js` einsetzen.
3. Prüfen, dass der Editor keine Fehler anzeigt, anschließend **Bereitstellen**.
4. Workers-AI-Bindung `AI`, D1-Bindung `DB` und Secret `NEOKI_ACCESS_TOKEN` bleiben unverändert.

## 2. Android über GitHub Actions
1. Die ZIP-Datei `NeoKI_Android_Projekt_v0.9.6_Stilwahl.zip` ohne Entpacken ins GitHub-Repository hochladen.
2. Unter `.github/workflows/android-apk.yml` nur die ZIP-Datei im Schritt `Projekt entpacken` aktualisieren:

   `run: unzip -q NeoKI_Android_Projekt_v0.9.6_Stilwahl.zip -d projekt`

   Falls GitHub die Datei beim Download/Upload umbenennt, muss der tatsächliche GitHub-Dateiname verwendet werden.
3. `Commit changes` speichern; unter `Actions` den neu gestarteten Build kontrollieren.
4. Bei grüner Markierung unter `Artifacts` das Paket `NeoKI-APK` laden, ZIP entpacken, `app-debug.apk` installieren.
5. Im Setup die Serveradresse und den **privaten** Zugangsschlüssel eingeben; Schlüssel nicht an Dritte geben.

## 3. Tests
- **Stil:** In Setup erst `Direkt` auswählen. Im Chat fragen: `Warum ist der Himmel blau? Antworte knapp.` Danach `Herzlich` wählen und die Antwort vergleichen.
- **Eigeninitiative:** Schalter ausschalten; in einem neuen Chat fragen: `Ich habe heute eine Stunde Zeit.` Dann einschalten und die Antwort auf `Ich möchte heute etwas Neues ausprobieren` vergleichen.
- **Gedächtnis:** `Ich plane einen Ausflug nach Hamburg.` Danach `Wohin plane ich einen Ausflug?` – Neo sollte sich erinnern. `Neuer Chat` muss den Sitzungsverlauf zurücksetzen.
- **Erwachsenenthemen:** Im Setup freiwillig aktivieren und sachliche Frage zu Sexualität/Medien beantworten lassen. Keine Garantie expliziter Darstellungen.
- **Regression:** Bild erzeugen und speichern; Wetterfrage und Gedächtniseintrag prüfen.

## Grenzen
- Die freie Modellauswahl ist durch Cloudflare Workers AI und dein kostenloses Kontingent begrenzt. Höhere Modellqualität oder unbeschränkte explizite Ausgaben können nicht durch einen App-Schalter erzwungen werden.
- Lokale JavaScript-Tests ersetzen keine Live-Cloudflare-Probe und keinen Android-Bau. Erst der GitHub-Actions-Lauf bestätigt die APK-Kompilierung.
