# Neo KI 0.9.7 – Staerkeres Modell und Lernen aus Korrekturen

## Was ist neu?
- Optionales, leistungsfaehigeres Cloudflare-Textmodell Llama 3.3 70B (bei Kapazitaetsproblemen begrenzter Rueckfall auf das bisherige 8B-Modell).
- Im Chat: Knopf **Lernregel**. Jede Regel erfordert ausdrueckliche Bestaetigung vor dem dauerhaften Speichern.
- Wenn du schreibst `Das war falsch: Die Hauptstadt von Polen ist Warschau.`, zeigt Neo einen Lernvorschlag zum Bestaetigen.
- Gespeicherte Lernregeln stehen mit Praefix `Lernregel:` im vorhandenen D1-Gedaechtnis und koennen dort geloescht werden.
- Direkte Antworten sind kuerzer. Bildstudio, Arbeitsmodus, Erwachsenenmodus und Recherche bleiben enthalten.

## Installation
1. Alten Cloudflare-Worker `worker.js` als Rueckfall sichern.
2. Die beigelegte vollstaendige `NeoKI_0.9.7_Cloudflare_Code.txt` in Cloudflare einfuegen, auf 0 Fehler pruefen und bereitstellen.
3. Android-ZIP `NeoKI_Android_Projekt_v0.9.7_Lernmodus.zip` in dein GitHub-Repository laden.
4. Im GitHub Actions Workflow `.github/workflows/android-apk.yml` nur die unzip-Datei aendern (EXAKTEN Namen bei GitHub kontrollieren, haeufig `-1.zip`).
5. Build in Actions abwarten, `NeoKI-APK` herunterladen, ZIP entpacken und `app-debug.apk` installieren.

## Tests
- Frage mit eingeschaltetem Leistungsmodus. Unter der KI-Antwort sollte bei Erfolg `KI-Modell: Llama 3.3 70B` stehen.
- Korrigiere einen Fehler: `Das war falsch: Eine Woche hat sieben Tage, nicht acht.`
- Tippe auf `Vorschlag pruefen und speichern`; die Regel darf ERST nach ausdruecklicher Bestaetigung in `Gedaechtnis` erscheinen.
- Spaeter dieselbe Frage stellen und pruefen, ob Neo die Lernregel passend nutzt.
- Pruefe Bildstudio und Erwachsenenmodus.

## Grenzen und Datenschutz
- Kein autonomes Neutraining der Modellgewichte, keine eigenstaendigen 24/7-Laeufe.
- Nicht jede Korrektur ist wahr. Neo behandelt Regeln als unbestaetigten Nutzerkontext.
- Gespeicherte Regeln liegen im bestehenden Cloudflare D1 und koennen ueber `Gedaechtnis` geloescht werden.
- Cloudflare Workers AI Free enthaelt laut Dokumentation 10.000 Neurons taeglich. Das 70B-Modell benoetigt ein Vielfaches des Kontingents des kleineren Modells. Bei Bezahlplaenen koennen zusaetzliche Nutzungsentgelte anfallen: Kosten im Cloudflare-Dashboard pruefen.
- Explizite pornografische Text- und Bildgenerierung wird durch diese Version nicht entsperrt. Der Erwachsenenmodus kann ueber erwachsene Erotik und Pornografie offen sprechen, soweit das KI-Modell es erlaubt.
