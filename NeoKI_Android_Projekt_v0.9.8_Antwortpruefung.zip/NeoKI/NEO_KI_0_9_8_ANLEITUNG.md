# Neo KI 0.9.8 – Antwortprüfung und Widerspruchsschutz beim Lernen

## Was ist neu?

1. **Freiwillige Antwortprüfung**: Neuer Schalter im Android-Setup (standardmäßig AUS). Nach einer normalen Chatantwort kann ein zweites, kleineres Workers-AI-Modell offensichtliche Widersprüche zur Aufgabenstellung oder bereitgestellten Quellen markieren. Die ursprüngliche Antwort wird nicht heimlich umgeschrieben. Ein Hinweis ist **keine unabhängige Faktenprüfung** und kann falsch sein.
2. **Transparenz bei Lernregeln**: Unter geeigneten Chatantworten zeigt Neo KI die IDs der an das Modell übergebenen Lernregeln an. Das ist ein Nachweis für die Übergabe als Kontext, nicht für eine garantierte Befolgung.
3. **Schutz gegen widersprüchliche Lernregeln**: Wenn eine neue bestätigte Regel offensichtlich die bisherige Antwortlängen-Vorliebe (kurz / ausführlich) widerspricht, stoppt Neo KI das Speichern und nennt die ID der alten Regel. Entscheide selbst, ob du die alte Regel im Tab "Gedächtnis" löschen möchtest. Der Schutz ist absichtlich auf eindeutige Gegensatzpaare begrenzt.
4. **Präzisere Systemanweisung**: Bei Entwicklungsplänen soll Neo KI bereits vorhandene Datenbanken und Funktionen berücksichtigen.

Der größere 70B-Modus, das Gedächtnis, die Gesprächsstile, die Quellenrecherche, das Bildstudio und der freiwillige Erwachsenenmodus bleiben enthalten.

## Installation, Teil 1 – Cloudflare

1. Den **aktuell funktionierenden Worker 0.9.7 sichern**.
2. `NeoKI_0.9.8_Cloudflare_Code.txt` öffnen, alles kopieren und in `worker.js` beim Cloudflare-Worker `neoki-gedaechtnis-test` einsetzen.
3. Nach **0 Fehlern** auf **Bereitstellen** tippen.
4. Die bestehende D1-Bindung `DB`, Workers-AI-Bindung `AI` und das Secret `NEOKI_ACCESS_TOKEN` unverändert lassen. Zugangsschlüssel niemals in Dateien oder Chats kopieren.

## Installation, Teil 2 – Android

1. `NeoKI_Android_Projekt_v0.9.8_Antwortpruefung.zip` **als ZIP** zu `mebert1805-alt/NeoKI-Android` hochladen.
2. In `.github/workflows/android-apk.yml` die `run: unzip -q ... -d projekt`-Zeile auf den **exakten GitHub-ZIP-Dateinamen** ändern. GitHub kann den Namen beim Hochladen durch `-1` ergänzen.
3. Die Änderung mit `Commit changes` bestätigen, GitHub Actions öffnen.
4. Nach **Success** das Artefakt `NeoKI-APK` herunterladen, entpacken und `app-debug.apk` installieren.
5. Die App ist mit einer eigenen Paketkennung für 0.9.8 ausgelegt; die alte Version bleibt als Rückfallmöglichkeit separat installiert.

## Tests

- **Setup:** Optionalen Schalter `Antwortprüfung (zusätzlicher KI-Aufruf)` ansehen. Der Schalter muss anfangs AUS sein.
- **Lernen:** Vorhandene kurze Lernregel beibehalten, dann absichtlich eine widersprechende Lernregel zu ausführlichen Antworten vorschlagen. Neo soll das Speichern mit einem Hinweis auf die bestehende Regel verweigern. **Nichts wird automatisch gelöscht.**
- **Chat:** Frage im natürlichen oder herzlichen Stil stellen. Wenn eine relevante Lernregel an das Modell übergeben wurde, zeigt die App deren Nummer an.
- **Antwortprüfung:** Schalter nach Wunsch einschalten und eine gewöhnliche Chatfrage senden. Neo meldet `Keine eindeutigen Widersprüche erkannt`, einen konkreten Prüfhinweis oder `Prüfung nicht verfügbar`.
- **Regression:** Bildstudio testen und ein Bild speichern; Gedächtnis und Erwachsenenmodus aufrufen.

## Grenzen und Kosten

- Diese Version trainiert die Modellgewichte **nicht selbstständig**. Nutzerbestätigungen bleiben Voraussetzung für neue dauerhafte Lernregeln.
- Ein zusätzliches KI-Modell kann Aussagen plausibilisieren, aber nicht ohne unabhängige Quellen deren Richtigkeit beweisen.
- Die optionale Antwortprüfung benötigt **einen weiteren KI-Aufruf pro normaler Chatantwort**, verbraucht also zusätzlich vom Workers-AI-Tageskontingent. Manche spezialisierten Funktionen (z. B. Wetter, Recherche, Arbeitsauftrag) laufen auf ihren vorhandenen Pfaden ohne diese zusätzliche Prüfung.
- Es werden **keine neuen Datenbanktabellen** angelegt und ohne Zustimmung keine Lernregeln geschrieben.
- Unbegrenzte oder pornografische Generierung wird durch dieses Update nicht freigeschaltet. Die bestehenden Modell- und Sicherheitsgrenzen gelten weiter.

## Prüfstand

- JavaScript-Syntaxprüfung erfolgreich.
- 17 lokale Worker-Funktionstests erfolgreich mit simulierten KI-/D1-Antworten.
- Android-Dateien gegenüber dem bisher gebauten 0.9.7-Projekt gezielt erweitert; der **echte Android-APK-Bau und Live-Test stehen noch aus**.
