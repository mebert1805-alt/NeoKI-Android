# Neo KI Android 0.9.3 – Bildfunktion direkt in der App

## Was ist neu?
In dieser Version gibt es unten den fünften Bereich **Bilder** (neben Chat, Wissen, Gedächtnis und Setup). Im Bilder-Reiter kannst du einen 4–700 Zeichen langen Text eingeben, ein fotorealistisches Bild mit Cloudflare Workers AI erstellen und als JPG über den Android-Dateidialog speichern.

## Wichtig: Alte App bleibt erhalten
Diese Fassung hat bewusst die **eigene App-ID `de.neoki.app.cloud.images`**, weil GitHub auf jedem Build-Runner einen anderen Debug-Signaturschlüssel erzeugen kann und ein Update der bereits installierten Neo-KI-App sonst möglicherweise blockiert wird. Du kannst sie daher als **Neo KI Bilder** neben der bisherigen Neo KI installieren. Es werden weder die bestehende App noch ihre lokal gespeicherten Einstellungen gelöscht. Du musst die bestehende Cloudflare-Serveradresse und deinen aktuellen Secret-Zugangsschlüssel einmal erneut im Reiter **Setup** eingeben (ohne `Bearer`). Der Schlüssel wird verschlüsselt über Android Keystore gespeichert und ist **nicht** im APK-Quellcode hinterlegt.

## Online-APK bauen (nur Tablet + Xiaomi)
1. Lade `NeoKI_Android_Projekt_v0.9.3_Bilder.zip` ins GitHub-Repository `mebert1805-alt/NeoKI-Android` hoch (Root-Verzeichnis; als ZIP belassen).
2. Öffne die vorhandene Datei `.github/workflows/android-apk.yml` und ändere in der Zeile `run: unzip -q ... -d projekt` ausschließlich den ZIP-Namen auf `NeoKI_Android_Projekt_v0.9.3_Bilder.zip`. Alle übrigen Zeilen **unverändert** lassen.
3. `Commit changes` → unter `Actions` den neuen Lauf `Neo KI Android APK` prüfen. Nur bei **grünem Haken** unter `Artifacts` → `NeoKI-APK` herunterladen, entpacken und darin `app-debug.apk` auf dem Xiaomi installieren.
4. Öffne die App `Neo KI Bilder` → **Setup**. Server: `https://neoki-gedaechtnis-test.mebert1805.workers.dev` ohne `/image`, `/chat`, `/image-studio`. Geheimen Zugangsschlüssel nur am Handy eingeben – nicht in GitHub, nicht hier im Chat und nicht im Screenshot zeigen.
5. Wechsle zu **Bilder** → Textbeschreibung eingeben → **Bild erzeugen** → bei Erfolg **Bild als JPG speichern**.

## Voraussetzung
Auf Cloudflare ist dein bereits erfolgreich getesteter Neo-KI-Bildserver 0.9.2 installiert: `POST /image` erwartet `{ "prompt": "..." }` und antwortet nach `Authorization: Bearer <secret>` mit `{ "image": "data:image/jpeg;base64,..." }`.

## Grenzen
- Die APK ist erst nach dem **GitHub-Online-Bau** verfügbar, hier wurde keine APK kompiliert.
- Bilddaten bleiben nur im Arbeitsspeicher bis zum App-Neustart, außer du speicherst sie explizit als JPG.
- Die Bilderstellung verbraucht Cloudflares kostenloses Workers-AI-Kontingent; bei Erreichen des Limits schlägt sie fehl.
- Der vorhandene Cloudflare-Worker ist durch ein gemeinsames Secret geschützt, nicht durch vollständige Mehrbenutzerkonten. Veröffentliche den Secret-Wert nie im GitHub-Repository.
- Debug-Build nicht in App-Stores veröffentlichen.
