# Neo KI Cloud 0.3 – Installation auf dem Xiaomi

**Cloudflare-kompatible Android-Fassung.** Neue App-ID (`de.neoki.app.cloud`), damit sie zusätzlich zur ursprünglichen Neo-KI-App installiert werden kann; die alte Version bleibt erhalten.

## Was diese Version kann
- Chat mit dem bestehenden Cloudflare-Worker über `POST /chat`, liest JSON `answer`.
- Server-URL und **persönlicher Bearer-Schlüssel**, den du nur am Telefon im Reiter Setup eingibst.
- Der Schlüssel wird mithilfe des Android Keystore AES-GCM verschlüsselt auf dem Telefon gespeichert, nicht in der APK eingebaut.
- Gedächtnis und Wissen lesen, erstellen, löschen über die `/memories`-Endpunkte; Wissensnotizen werden als `Wissen: Titel\nText` gespeichert (maximal 2000 Zeichen), über dieselbe D1-Tabelle.
- Verwendet HTTPS; kein Klartext-HTTP.

## Wichtige Grenzen
- Der Cloudflare-Worker **speichert Chats nicht** und unterstützt keine Internetrecherche. Der Chatverlauf wird nur in der laufenden App-Sitzung gehalten. Keine automatische Modellausbildung.
- Wissen und Gedächtnis sind ein gemeinsamer persönlicher Speicher hinter demselben geheimen Zugangsschlüssel. Derzeit kein Mehrbenutzersystem.
- Unter Android erscheint beim Installieren `Neo KI Cloud`; die ältere Neo-KI-App kannst du vorerst behalten.
- Die APK ist ein **Debug-Build**. Installiere nur deine eigene aus deinem GitHub Actions-Lauf und prüfe deren Herkunft.

## APK online bauen
1. Neue Datei `NeoKI_Android_Projekt_v0.3_Cloudflare.zip` in dein GitHub-Repository `NeoKI-Android` hochladen.
2. In `.github/workflows/android-apk.yml` beide Vorkommen der ZIP-Datei `NeoKI_Android_Projekt_v0.2.zip` (sofern vorhanden) zu `NeoKI_Android_Projekt_v0.3_Cloudflare.zip` ändern. Für den bestehenden Workflow ist normalerweise nur die `unzip`-Zeile anzupassen.
3. `Commit changes`, anschließend auf GitHub `Actions` den nächsten Lauf prüfen.
4. Bei Erfolg unter `Artifacts` → `NeoKI-APK` das ZIP downloaden, entpacken, `app-debug.apk` auf dem Xiaomi öffnen/installieren.

## Setup in der neuen App
Serveradresse: `https://neoki-gedaechtnis-test.mebert1805.workers.dev` (ohne `/chat` oder `/memories`).
Zugangsschlüssel: **der neue, nicht öffentlich gezeigte** Wert deines Cloudflare-Secrets `NEOKI_ACCESS_TOKEN` (ohne `Bearer` davor). In einem Passwortmanager aufbewahren. Niemals in Chat oder Screenshots zeigen.
Button `Server und Zugang speichern`, dann `Chat` → Testfrage `Was ist mein Lieblingstier?`.

**Hinweis:** Android-Compilation und Installation auf dem Xiaomi wurden hier nicht durchgeführt. Der GitHub-Actions-Build zeigt, ob das Projekt kompiliert.
