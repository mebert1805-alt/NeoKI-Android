# Neo KI · Android-App mit Internet, Wissen und Arbeitsmodus

**Version 0.2 – Quellcode-Prototyp, noch keine installierfertige APK**

Neo KI ist eine Android-Chat-App für ein Xiaomi/Android-Handy. Die KI läuft nicht vollständig auf dem Gerät: Der Android-Client verbindet sich mit einem Python/FastAPI-Server, der die OpenAI Responses API nutzt. **Zuerst Android; ein Windows-Client ist für eine spätere Entwicklungsphase vorgesehen und hier noch nicht enthalten.**

## Was derzeit im Quellcode steckt

- **Chat mit Gedächtnis**: Der Server speichert Gesprächsverlauf sowie kurze, explizit genannte Vorlieben/Ziele in SQLite (abschaltbar und löschbar). Kein kontinuierliches Neutrainieren des Modells.
- **Internetrecherche per Schalter**: „🌐 Internet“ aktiviert das integrierte OpenAI-Tool `web_search` im nächsten Chataufruf. Falls das Modell Quellenzitierungen liefert, werden Quellen-Links in der App angezeigt. Ohne Schalter keine aktive Websuche.
- **Wissensdatenbank**: Bis zu 75 eigene Einträge mit Titel und Text (bis zu 8.000 Zeichen), lokal auf deinem privaten Server in SQLite. Beim Chatten werden bis zu vier anhand von Stichwörtern passende Einträge genutzt. Das ist eine einfache Suche, keine semantische Vektordatenbank.
- **Aus Webrecherche lernen**: Eine KI-Antwort lässt sich über „Ins Wissen übernehmen“ bewusst als wiederverwendbare Wissensnotiz speichern. **Webseiten und KI-Antworten können fehlerhaft sein** – Fakten vor dem Speichern prüfen. Keine stille dauerhafte Übernahme aller Internetdaten.
- **🛠 Arbeiten**: Arbeitsmodus formuliert Ergebnisse wie Recherchen, Zusammenfassungen, Entwürfe, Checklisten und Pläne. **Er führt keine externen Aktionen durch** (keine E-Mails versenden, Konten bedienen, Apps steuern oder Webseiten automatisch ändern).
- **Löschen**: Chats, Erinnerungen und Wissenseinträge können einzeln bzw. komplett vom Server gelöscht werden. Sicherungskopien können separat bestehen bleiben.

**Kein universeller Datenbankzugriff**: Die SQLite-Wissensdatenbank ist enthalten. Externe Datenbanken, Unternehmens-Apps oder private Online-Konten brauchen später gesonderte, erlaubte Schnittstellen, Zugangsdaten und Berechtigungsprüfungen.

## Voraussetzungen

- Ein Xiaomi/Android-Smartphone und zum **Bauen der APK** ein Computer mit Android Studio, JDK 17 und Android SDK 36 (Android Studio läuft z.B. auf Windows, Linux oder macOS). Der Windows-**Desktop-Client** ist erst Phase 2.
- Ein von deinem Handy erreichbarer **Python-Server 3.11+** oder entsprechender Hosting-Dienst.
- Ein **eigener OpenAI API-Schlüssel**, ausreichendes Guthaben und ein für die gewählten Modelle freigeschalteter Zugang. Standardmodelle im Beispiel: `gpt-5-mini` für Chat und `gpt-4.1-mini` zum Erkennen langfristiger Vorlieben. Ändere sie bei Bedarf über Server-Umgebungsvariablen.
- Internetverbindung. **API-Nutzung und Websuche können Kosten verursachen.** Eine ChatGPT-Plus-Mitgliedschaft ersetzt den API-Schlüssel nicht.

## Server installieren

Im Ordner `server`:

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

API-Schlüssel ausschließlich auf dem Server setzen:

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="DEIN_API_SCHLUESSEL"
$env:NEO_CHAT_MODEL="gpt-5-mini"
$env:NEO_LEARN_MODEL="gpt-4.1-mini"
```

Linux/macOS:
```bash
export OPENAI_API_KEY="DEIN_API_SCHLUESSEL"
export NEO_CHAT_MODEL="gpt-5-mini"
export NEO_LEARN_MODEL="gpt-4.1-mini"
```

Starten:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

Test im privaten Heimnetz: `http://127.0.0.1:8000/health` auf dem Server und `http://IP-DES-SERVERS:8000/health` auf dem Handy (gleiches WLAN, lokale Firewall beachten). Trage `http://IP-DES-SERVERS:8000` unter „Setup“ in Neo KI ein.

Für den späteren Betrieb unterwegs ist eine korrekt abgesicherte HTTPS-Umgebung nötig. **Den Beispielserver nicht direkt ins öffentliche Internet freigeben**. Kein Benutzer-Login, keine Limits, keine Kontoverwaltung: die reine Gerätekennung ist keine sichere Authentifizierung. Vor öffentlichem Hosting erst Authentifizierung, Zugriffsrechte, Rate-Limits, HTTPS und Datenschutz vervollständigen.

## Android-App bauen/installieren

1. Android Studio öffnen, den Ordner `android` importieren.
2. SDK 36 installieren, Gradle synchronisieren lassen. **Wrapper-JAR ist nicht im Paket**; Android Studio/Gradle-Installation muss Gradle bereitstellen oder den Wrapper vervollständigen.
3. Auf deinem Xiaomi Entwickleroptionen und USB-Debugging für den Test aktivieren, mit dem Computer verbinden, Berechtigung bestätigen.
4. In Android Studio `Run` wählen oder über das Build-Menü eine Debug-APK erstellen und auf dem eigenen Gerät installieren.
5. Im „Setup“-Tab die Serveradresse speichern. Unter „Chat“ kannst du Internet und Arbeiten ein- oder ausschalten. Unter „Wissen“ kannst du eigene Daten hinzufügen und entfernen.

**Status**: Die Python-Tests können automatisiert ausgeführt werden. Der Android-Client wurde in dieser Entwicklungsumgebung weder kompiliert noch auf dem Xiaomi getestet. Das Projekt kann daher noch Anpassungen beim Android-Build benötigen.

## Schutz und Grenzen

- Schalte Internet nur ein, wenn du tatsächlich Webrecherche brauchst. Die Nutzung des Webtools kostet möglicherweise zusätzlich. OpenAI-Websuche kann unzuverlässige oder veraltete Seiten finden; wichtige Behauptungen überprüfen.
- Gib keine Passwörter, TANs, Geheimnisse oder sensiblen personenbezogenen Daten in die Wissensdatenbank ein. Diese Einträge werden bei passenden Anfragen zusammen mit dem Chat für die KI-Antwort an den KI-Anbieter übermittelt; die Wissensdatenbank liegt auf deinem Server.
- Der Server setzt für die KI-Aufrufe `store=False`. Das deaktiviert nicht alle Protokollierungs- oder Aufbewahrungsprozesse beim Dienstanbieter; informiere dich über die geltenden Datenschutzbedingungen.
- Die Android-Demo lässt zur lokalen Entwicklung unverschlüsseltes HTTP zu (`usesCleartextTraffic=true`). Für produktiven Betrieb **abschalten und HTTPS verwenden**.
- Es findet **keine dauerhafte selbstständige Hintergrundrecherche** statt und Neo KI installiert keine Updates ihres KI-Modells selbst.
- Der aktuelle Wissenssuchalgorithmus ist bewusst einfach und findet nicht jede Formulierung. Eine spätere Version kann Embeddings, Dokumentimport, Synonyme und Zugriffsprüfung hinzufügen.

## Automatische Server-Tests ohne API-Kosten

```bash
cd server
pip install pytest httpx
python -m pytest -q
```

Die Tests verwenden eine simulierte KI und prüfen Chats, Wissen, Zugriffstrennung anhand der Gerätekennung, Ein-/Ausschalten der Websuche, Quellen, Erinnerungen und Löschen. **Dies ist keine vollständige Sicherheitsprüfung.**


## Version 0.9.3 Bilder
Neu: Android-Reiter Bilder mit POST /image und JPG-Speicherung. Anleitung: `NEO_KI_BILDER_INSTALLATION.md`.
