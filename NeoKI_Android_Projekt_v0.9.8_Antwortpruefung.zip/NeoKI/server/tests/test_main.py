"""Tests without network calls or a real API key."""
from types import ModuleType, SimpleNamespace
from uuid import uuid4
import sys

# Test-only shim if the SDK is unavailable in the sandbox. Real server needs
# `pip install -r requirements.txt` and imports the genuine OpenAI SDK.
try:
    from openai import OpenAI  # noqa: F401
except ImportError:
    stub = ModuleType("openai")
    stub.OpenAI = object
    sys.modules["openai"] = stub

from fastapi.testclient import TestClient
import main


class FakeResponses:
    def create(self, **kwargs):
        if 'Extrahiere' in kwargs.get('instructions', ''):
            return SimpleNamespace(output_text='{"memory": "Die Person lernt Spanisch."}')
        return SimpleNamespace(output_text='¡Hola! Wie kann ich helfen?')


class FakeOpenAI:
    responses = FakeResponses()


def test_chat_and_learning(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    monkeypatch.setattr(main, "client", lambda: FakeOpenAI())
    app = TestClient(main.app)
    device = str(uuid4())

    health = app.get('/health')
    assert health.status_code == 200
    assert app.get('/history', params={'device_id': device}).json() == {'messages': []}
    reply = app.post('/chat', json={
        'device_id': device,
        'message': 'Ich lerne Spanisch',
        'auto_learn': True,
    })
    assert reply.status_code == 200, reply.text
    assert len(reply.json()['messages']) == 2
    assert reply.json()['reply'].startswith('¡Hola!')

    saved = app.get('/memories', params={'device_id': device}).json()['memories']
    assert len(saved) == 1
    deleted = app.delete(f'/memories/{saved[0]["id"]}', params={'device_id': device})
    assert deleted.status_code == 200
    assert app.get('/memories', params={'device_id': device}).json()['memories'] == []

    app.delete('/data', params={'device_id': device})
    assert app.get('/history', params={'device_id': device}).json()['messages'] == []


def test_validation(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    app = TestClient(main.app)
    assert app.get('/history', params={'device_id': 'invalid'}).status_code == 422
    assert app.post('/chat', json={'device_id': str(uuid4()), 'message': ''}).status_code == 422


def test_no_learning(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    monkeypatch.setattr(main, "client", lambda: FakeOpenAI())
    app = TestClient(main.app)
    device = str(uuid4())
    assert app.post('/chat', json={'device_id': device, 'message': 'Hallo', 'auto_learn': False}).status_code == 200
    assert app.get('/memories', params={'device_id': device}).json()['memories'] == []


def test_knowledge_and_search_context(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    captured = []

    class InspectResponses(FakeResponses):
        def create(self, **kwargs):
            captured.append(kwargs)
            return super().create(**kwargs)

    monkeypatch.setattr(main, "client", lambda: SimpleNamespace(responses=InspectResponses()))
    app = TestClient(main.app)
    device = str(uuid4())
    other = str(uuid4())

    created = app.post('/knowledge', json={
        'device_id': device, 'title': 'Gartenprojekt Tomaten', 'body': 'Tomaten brauchen Sonne und regelmäßiges Wasser.'
    })
    assert created.status_code == 201, created.text
    item_id = created.json()['id']
    assert len(app.get('/knowledge', params={'device_id': device}).json()['knowledge']) == 1
    assert app.get('/knowledge', params={'device_id': other}).json()['knowledge'] == []
    assert app.post('/chat', json={
        'device_id': device, 'message': 'Wie pflege ich Tomaten?', 'auto_learn': False,
        'work_mode': True, 'use_web': True,
    }).status_code == 200
    assert captured[0]['tools'] == [{'type': 'web_search', 'search_context_size': 'medium'}]
    assert 'Gartenprojekt Tomaten' in captured[0]['instructions']
    assert 'Arbeitsmodus' in captured[0]['instructions']
    assert app.delete(f'/knowledge/{item_id}', params={'device_id': other}).status_code == 200
    assert len(app.get('/knowledge', params={'device_id': device}).json()['knowledge']) == 1
    assert app.delete(f'/knowledge/{item_id}', params={'device_id': device}).status_code == 200
    assert app.get('/knowledge', params={'device_id': device}).json()['knowledge'] == []


def test_web_flag_off_and_clear_all_data(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    calls = []
    class CapturedResponses(FakeResponses):
        def create(self, **kwargs):
            calls.append(kwargs)
            return super().create(**kwargs)
    monkeypatch.setattr(main, "client", lambda: SimpleNamespace(responses=CapturedResponses()))
    app = TestClient(main.app)
    device = str(uuid4())
    assert app.post('/knowledge', json={'device_id': device, 'title': 'Notiz', 'body': 'Eine Probe'}).status_code == 201
    assert app.post('/chat', json={'device_id': device, 'message': 'Hallo', 'auto_learn': False}).status_code == 200
    assert 'tools' not in calls[0]
    assert app.delete('/data', params={'device_id': device}).status_code == 200
    assert app.get('/knowledge', params={'device_id': device}).json()['knowledge'] == []
    assert app.get('/history', params={'device_id': device}).json()['messages'] == []


def test_web_source_extraction():
    annotation = SimpleNamespace(type='url_citation', url='https://example.com', title='Beispiel')
    output = [SimpleNamespace(content=[SimpleNamespace(annotations=[annotation, annotation])])]
    assert main.output_sources(SimpleNamespace(output=output)) == [{'url': 'https://example.com', 'title': 'Beispiel'}]


def test_knowledge_validation(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "DB_PATH", tmp_path / "test.sqlite3")
    app = TestClient(main.app)
    device = str(uuid4())
    assert app.post('/knowledge', json={'device_id': device, 'title': ' ', 'body': 'Test'}).status_code == 422
    assert app.post('/knowledge', json={'device_id': device, 'title': 'Test', 'body': ''}).status_code == 422
