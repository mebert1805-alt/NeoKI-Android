# Neo KI 0.9.9 – Android-App

Bildauswahl, Dokumentauswahl (PDF mit Text, TXT, MD), Kamera via Android-Kamera-App, Diktat via Android-Spracherkennung und Neon-Launcher-Icon.

Backend muss separat aus `NeoKI_0.9.9_Cloudflare_Code.txt` bei Cloudflare ausgetauscht werden. Die ZIP ist die Android-Projektdatei und enthält **keinen** geheimen Schlüssel.

Eine vollständige Installationsanleitung liegt separat als `NeoKI_0.9.9_Installationsanleitung.md` vor.

Technik: PDFBox-Android `2.0.27.0` (Apache 2.0) für PDF-Textauslese, Android Activity Result Contracts für Foto-, Datei- und Diktat-Auswahl. Keine dauerhafte Kamera-/Mikrofonüberwachung.

Wichtig: Eine neue applicationId bedeutet separate Installation und erneute Eingabe des Zugangsschlüssels ausschließlich in der App.
