package de.neoki.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Ein fluechtiger, ausgelesener und gekuerzter Dokumentauszug. */
data class SelectedDocument(val name: String, val text: String, val truncated: Boolean)

object AttachmentTools {
    private const val MAX_FILE = 6 * 1024 * 1024

    fun fileName(context: Context, uri: Uri): String {
        val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        return cursor?.use {
            if (it.moveToFirst()) it.getString(0) ?: "Anhang" else "Anhang"
        }?.replace(Regex("[\\r\\n]"), " ")?.take(120) ?: "Anhang"
    }

    private fun readLimited(context: Context, uri: Uri): ByteArray {
        return context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (out.size() + count > MAX_FILE) error("Datei zu gross (maximal 6 MB)")
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        } ?: error("Datei konnte nicht gelesen werden")
    }

    suspend fun loadDocument(context: Context, uri: Uri): SelectedDocument = withContext(Dispatchers.IO) {
        val name = fileName(context, uri)
        val bytes = readLimited(context, uri)
        val extension = name.substringAfterLast('.', "").lowercase()
        val text: String = when (extension) {
            "txt", "md" -> bytes.toString(Charsets.UTF_8)
            "pdf" -> {
                PDFBoxResourceLoader.init(context.applicationContext)
                PDDocument.load(bytes).use { doc ->
                    val lastPage = minOf(doc.numberOfPages, 15)
                    if (lastPage < 1) error("PDF enthaelt keine Seiten")
                    PDFTextStripper().apply { startPage = 1; endPage = lastPage }
                        .getText(doc).let { if (doc.numberOfPages > 15) it + "\n[Weitere PDF-Seiten wurden ausgelassen.]" else it }
                }
            }
            else -> error("Erlaubt sind PDF, TXT und MD")
        }.trim()
        if (text.isBlank()) error("Kein auslesbarer Text. Gescanntes PDF braucht spaeter OCR.")
        val truncated = text.length > 10500
        SelectedDocument(name, text.take(10500) + if (truncated) "\n[Auszug bei 10.500 Zeichen gekuerzt]" else "", truncated)
    }

    /** Bild wird VOR dem Upload lokal verkleinert und in JPEG umgewandelt. */
    suspend fun loadImage(context: Context, uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        val bytes = readLimited(context, uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth < 1 || bounds.outHeight < 1) error("Datei ist kein lesbares Bild")
        var sample = 1
        while (bounds.outWidth / sample > 1400 || bounds.outHeight / sample > 1400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: error("Bild nicht lesbar")
        val result = toJpeg(bitmap)
        bitmap.recycle()
        result
    }

    fun toJpeg(bitmap: Bitmap): ByteArray {
        val factor = minOf(1f, 1200f / maxOf(bitmap.width, bitmap.height).toFloat())
        val scaled = if (factor < 1f) Bitmap.createScaledBitmap(bitmap,
            maxOf(1, (bitmap.width * factor).toInt()), maxOf(1, (bitmap.height * factor).toInt()), true) else bitmap
        val out = ByteArrayOutputStream()
        if (!scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)) error("Bildkomprimierung fehlgeschlagen")
        if (scaled !== bitmap) scaled.recycle()
        val result = out.toByteArray()
        if (result.size > 1_300_000) error("Bild nach Verkleinerung noch zu gross")
        return result
    }
}
