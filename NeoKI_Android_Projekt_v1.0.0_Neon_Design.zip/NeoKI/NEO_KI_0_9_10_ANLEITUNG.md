# Neo KI 0.9.10 – Dokument-Update

**Basis:** Neo KI 0.9.9. Bisherige Funktionen einschliesslich Neon-Icon, Kamera, Bildanalyse mit Mistral Vision, Sprach-Diktat, Gedächtnis, Lernregeln, Bildstudio und 70B-Opt-in bleiben enthalten.

## Neue Funktionen
- Android liest nun DOCX lokal als Word-Text aus (`word/document.xml` im Office-Open-XML-ZIP).
- PDF/TXT/MD und nun auch CSV/JSON koennen direkt als Textauszug an Cloudflare uebermittelt werden.
- Cloudflare analysiert den TEXTAUSZUG der Android-App direkt; keine volle Originaldatei wird verschickt.
- Datenschutz: nur von dir ausgewählte Dokumente, max. 6 MB Quelldatei und höchstens ca. 10.500 Zeichen Auszug.
- PDF ist weiterhin nur textbasiert auslesbar, Scans benoetigen spaeter OCR; bei PDF max. 15 Seiten.
- DOCX-Bilder, Kommentare, Fussnoten, Kopf- und Fusszeilen werden **nicht** ausgewertet.
- Bildanalyse verwendet Mistral Small 3.1 Vision (statt EU-eingeschraenktem Llama Vision), was bereits zuvor auf dem Xiaomi erfolgreich getestet wurde.

## Installieren
1. Aktuellen Cloudflare-Worker 0.9.9 zuerst als Sicherheitskopie speichern.
2. `NeoKI_0.9.10_Cloudflare_Code.txt` **vollständig** in `worker.js` ersetzen. Syntax: 0 Fehler. Bereitstellen.
3. Android-ZIP `NeoKI_Android_Projekt_v0.9.10_Dokumente.zip` zu `https://github.com/mebert1805-alt/NeoKI-Android/upload/main` hochladen; Commit changes.
4. `.github/workflows/android-apk.yml` die Zeile unter Projekt entpacken auf **genauen** ZIP-Namen aendern:
   `run: unzip -q NeoKI_Android_Projekt_v0.9.10_Dokumente.zip -d projekt`
5. Commit changes, GitHub Actions gruenen Erfolg abwarten, Artifact `NeoKI-APK` herunterladen, APK installieren.
6. Da separate Paket-ID `de.neoki.app.cloud.multimodal010`, Serveradresse + deinen **eigenen** geheimen Token im Android-Setup erneut speichern. Token niemals hier teilen.
7. Teste zuerst eine harmlose kleine TXT-Datei, danach eine PDF und eine DOCX. Falls Fehler: Screenshot senden.

## Grenzen / Tests
- Lokale Worker-Tests ersetzen keine reale Cloudflare-/Android-Testinstallation.
- DOCX-Auszug arbeitet lokal. Dokumente mit eingebetteten Tabellen sind als Fliesstext lesbar, Layout geht verloren.
- Bei langen Dateien arbeitet die App nur mit dem Anfang. Kein OCR fuer Bild-PDFs, keine Volltextindexierung.
- Keine neue D1-Tabelle, keine automatischen Wissenseintraege; Nutzerbestaetigung bleibt noetig.
- Kosten: bestehendes kostenloses Cloudflare Workers-AI-Kontingent, kein automatisches Bezahl-Upgrade.
