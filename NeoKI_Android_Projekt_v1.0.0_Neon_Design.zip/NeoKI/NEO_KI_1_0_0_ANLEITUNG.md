# Neo KI 1.0 – Neon-Design (Android)

## Grundlage und Ziele

Die Android-App basiert auf dem vom Nutzer installierten und mit PDF/DOCX getesteten Neo KI 0.9.10.
Es handelt sich um ein **visuelles Update**: Der Cloudflare-Worker braucht **keine neue Version** und wird bei diesem Schritt nicht geändert.

**Neu:**
- dunkles Navy-Design mit kontrastreichen Cyan-, Blau-, Violett- und Pink-Akzenten
- originales rundes Neon-KI-App-Icon im Kopfbereich (bestehende Mipmap-Icons unverändert)
- responsive Startkarte für Smartphone und Tablet, Tablet-Seitenbereich ab 820 dp
- Neon-Rahmen für Nutzer- und KI-Nachrichten
- farbige Aktionsschaltflächen für Bild, Dokument, Kamera und Sprache
- dunkle Eingabeleiste mit prominentem Senden-Knopf
- neu gestaltete Navigationsleiste und farblich abgestimmte Bildstudio-, Wissens-, Gedächtnis- und Setup-Seiten

**Erhalten:** Chat, Cloudflare-Anbindung, D1-Wissen, Lernregeln, 70B-Auswahl, freiwillige Antwortprüfung,
Bildgenerierung, Galerie/Kamera-Bildanalyse, PDF-/DOCX-/TXT-/MD-Analyse, Android-Spracherkennung,
Setup-Optionen, Zugriffsschutz, optionaler Erwachsenenmodus und Nutzerbestätigung beim Speichern von Lernregeln.

## Auf GitHub installieren
1. ZIP `NeoKI_Android_Projekt_v1.0.0_Neon_Design.zip` herunterladen und **nicht entpacken**.
2. Bei https://github.com/mebert1805-alt/NeoKI-Android/upload/main hochladen und `Commit changes` bestätigen.
3. GitHub-Dateiname genau prüfen, falls dein Tablet eine Endung `-1.zip` angehängt hat.
4. Workflow öffnen: https://github.com/mebert1805-alt/NeoKI-Android/edit/main/.github/workflows/android-apk.yml
5. Unter `Projekt entpacken` den `unzip`-Befehl auf den **tatsächlich hochgeladenen Namen** stellen, z. B.:

   `run: unzip -q NeoKI_Android_Projekt_v1.0.0_Neon_Design.zip -d projekt`

6. `Commit changes` und GitHub Actions prüfen. Nur bei `Success` Artifact `NeoKI-APK` herunterladen.
7. Die Datei `app-debug.apk` aus dem Artifact-ZIP auf dem Xiaomi installieren.
8. Die App heißt `Neo KI 1.0 Neon`. Sie hat eine **separate Paket-ID** `de.neoki.app.cloud.neon100` und kann neben 0.9.10 installiert werden.
9. Im Setup dieselbe Cloudflare-HTTPS-Adresse und den **eigenen** geheimen Zugangsschlüssel eintragen. Niemals den Schlüssel im Chat oder in Screenshots zeigen.
10. Test: Chatfrage, PDF, DOCX, Bildanalyse, Kamera, Mikrofon, Bildstudio, Lernregel und Anzeige im Hoch- sowie Querformat.

## Teststatus / wichtige Grenzen
- Vollständiger Projektaufbau und kritische Dateien wurden lokal geprüft.
- Der vollständige Gradle-/Android-Build **konnte in dieser Umgebung nicht ausgeführt werden** (kein Android-SDK/Gradle verfügbar).
- Die GitHub-Actions-Erstellung und reale Installation **stehen noch aus**.
- Es wurde keine neue Bildanalyse-, Cloudflare- oder OCR-Funktion eingebaut: dies ist ein Designupdate.
- Die separate Test-App speichert den Schlüssel selbst im Android-Keystore; das alte App-Geheimnis wird nicht automatisch kopiert.
- Das UI ist an die Referenz angelehnt, nicht ein Pixel-für-Pixel-Nachbau des Designbilds.
