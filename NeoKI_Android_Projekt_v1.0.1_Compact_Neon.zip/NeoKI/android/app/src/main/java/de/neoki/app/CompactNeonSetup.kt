package de.neoki.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Reine UI-Komponenten fuer Neo KI 1.0.1. Keine Aenderungen an API/Server. */
private data class SetupEntry(
    val key: String, val icon: String, val title: String, val subtitle: String
)

@Composable
internal fun CompactSetupHome(isConnected: Boolean, onOpen: (String) -> Unit) {
    val entries = listOf(
        SetupEntry("ki", "✦", "KI-Einstellungen", "Modell und Arbeitsmodus"),
        SetupEntry("privacy", "♢", "Datenschutz", "Berechtigungen und Sicherheit"),
        SetupEntry("design", "◈", "Design", "Compact Neon · Dunkel"),
        SetupEntry("about", "ⓘ", "Über Neo KI", "Entwickler, Version und App-Informationen")
    )
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1027), Color(0xFF0B1027), NeoDeepBlue)))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⚙", fontSize = 26.sp, color = Color(0xFFB49DFF))
            Spacer(Modifier.width(10.dp))
            Text("Setup", color = NeoText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        Text("Einstellungen und Informationen", color = Color(0xFF9EAAC9), fontSize = 13.sp)
        if (!isConnected) {
            Text(
                "Noch nicht verbunden: Öffne KI-Einstellungen und speichere Server und Zugangsschlüssel.",
                modifier = Modifier.fillMaxWidth().background(NeoPurplePanel, RoundedCornerShape(12.dp)).padding(12.dp),
                color = NeoText, fontSize = 12.sp
            )
        }
        entries.forEach { entry ->
            val selectedAccent = entry.key == "about"
            val entryShape = RoundedCornerShape(16.dp)
            Row(
                Modifier.fillMaxWidth()
                    .clip(entryShape)
                    .background(if (selectedAccent) Color(0xFF241944) else Color(0xFF1A213C))
                    .border(1.dp, if (selectedAccent) Color(0xFF7351BD) else Color.Transparent, entryShape)
                    .clickable { onOpen(entry.key) }
                    .padding(horizontal = 13.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(entry.icon, color = Color(0xFFAA98F6), fontSize = 23.sp,
                    modifier = Modifier.width(32.dp), textAlign = TextAlign.Center)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(entry.title, color = NeoText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(entry.subtitle, color = Color(0xFF9EAAC9), fontSize = 12.sp)
                }
                Text("›", color = Color(0xFFA7AEC5), fontSize = 29.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Neo KI · Compact Neon", color = Color(0xFF949FBB), fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("Entwickelt von Marco Ebert", color = Color(0xFF949FBB), fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
internal fun CompactSetupSectionHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹ Setup", color = Color(0xFFB8A6FF)) }
        Spacer(Modifier.width(8.dp))
        Text(title, color = NeoText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun CompactDesignInformation() {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(NeoPanel).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Compact Neon · Dunkel", color = NeoText, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Text("Dunkles Navy, violette Neon-Akzente und kompakte Menükarten.",
            color = NeoMuted, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(NeoBackground, NeoPanel, NeoPurple, NeoCyan, NeoPink).forEach { color ->
                Box(Modifier.size(26.dp).clip(RoundedCornerShape(8.dp)).background(color)
                    .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(8.dp)))
            }
        }
        Text("Dieses Design ist in Version 1.0.1 fest eingestellt. Die KI- und Serverfunktionen ändern sich dadurch nicht.",
            color = NeoMuted, fontSize = 12.sp)
    }
}

@Composable
internal fun CompactAboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Über Neo KI") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Image(
                    painter = painterResource(id = R.mipmap.ic_launcher),
                    contentDescription = "Neo KI Logo",
                    modifier = Modifier.size(84.dp)
                )
                Text("Neo KI", color = NeoText, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Version 1.0.1 · Compact Neon", color = NeoMuted, fontSize = 13.sp)
                Text("Plattform: Android", color = NeoMuted, fontSize = 13.sp)
                Text("Entwickelt von Marco Ebert", color = NeoText, fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Text("Datenschutzinformationen findest du im Setup unter Datenschutz.",
                    color = NeoMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } },
        containerColor = NeoPanel,
        titleContentColor = NeoText,
        textContentColor = NeoText
    )
}
