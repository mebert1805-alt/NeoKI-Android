# Neo KI 1.0.1 – Compact Neon

**Dieses Paket ist der geänderte Android-Quellcode der gelieferten Version 1.0.0**, keine neu entworfene Web-Demo und keine fertige APK.

## Änderungen im echten Android-Projekt

- Setup-Übersicht mit vier Karten: KI-Einstellungen, Datenschutz, Design und Über Neo KI.
- Vorhandene Cloudflare-Server- und Token-Konfiguration sowie alle KI-Schalter in **KI-Einstellungen** verschoben, ohne die Aktionen zu ersetzen.
- Bestehende Datenschutzhinweise und Datenlöschung unter **Datenschutz**.
- Design-Unterseite informiert über das feste **Compact Neon · Dunkel**-Erscheinungsbild.
- **Über Neo KI** öffnet ein Infofenster mit Logo, Android, Version 1.0.1 und „Entwickelt von Marco Ebert“.
- Der Entwicklername erscheint klein am Ende der Setup-Übersicht; **nicht im Chat**.
- Android-Version auf `versionName = "1.0.1"`, `versionCode = 102` gesetzt. Die Paket-ID bleibt `de.neoki.app.cloud.neon100`.
- Der App-Titel wurde auf „Neo KI“ vereinheitlicht.

## Unverändert aus dem Projekt übernommen

`Api.kt`, `AttachmentTools.kt`, `SecretStore.kt`, `server/main.py`, die vorhandenen Tests und der bisherige Chat/Bildstudio-/Wissen-/Gedächtnis-Code wurden nicht funktional verändert. Es gibt **keine Änderungen an geheimen Schlüsseln oder Cloudflare-Endpunkten**.

## GitHub – auf dem Tablet

Repository (aus dem bisherigen Chat): https://github.com/mebert1805-alt/NeoKI-Android

1. Im GitHub-Repository auf **Add file → Upload files** gehen.
2. Die Datei `NeoKI_Android_Projekt_v1.0.1_Compact_Neon.zip` ins **Stammverzeichnis des Repositories** hochladen und committen. Ein neuer Branch für den Test ist vorzuziehen.
3. Die vorhandene Datei `.github/workflows/android-apk.yml` öffnen und den **`unzip`-Befehl** auf den neuen ZIP-Dateinamen setzen:

   `unzip -q NeoKI_Android_Projekt_v1.0.1_Compact_Neon.zip -d projekt`

4. Beim Build darauf achten, dass der Gradle-Befehl aus dem Ordner `projekt/NeoKI/android` ausgeführt wird. Falls der bestehende Workflow dort anders arbeitet, seine Projektpfade vor der Änderung prüfen.
5. Unter **Actions** den APK-Build starten bzw. das durch Commit ausgelöste Ergebnis prüfen. Erst bei grünem Build das erzeugte Artifact herunterladen.
6. Auf dem Tablet/Telefon Artifact entpacken und `app-debug.apk` installieren. Vorher die bisherige APK sicher aufbewahren.
7. In der App Setup und „Über Neo KI“ öffnen, dann Chat, PDF, DOCX, Kamera, Bildanalyse, Diktat, Lernregeln und Querformat testen.

**Wichtig:** Die alte Version 1.0.0 und 1.0.1 teilen dieselbe Paket-ID. Eine direkte Installation als Update klappt nur bei gleicher Android-Signatur. Falls das neue Debug-APK mit einer anderen Signatur erstellt wurde, die alte App nicht unüberlegt deinstallieren: Dabei könnten lokale Einstellungen und der gespeicherte Zugangsschlüssel verloren gehen.

## Verifizierungsstand

- Quelldateien aus dem vom Nutzer hochgeladenen v1.0.0-Paket untersucht und v1.0.1-Änderungen angewandt.
- Servertests aus der ZIP: 7 bestanden. Die Serverseite wurde nicht geändert.
- ZIP-Archivstruktur und enthaltene Kotlin-Dateien lassen sich prüfen.
- **Noch nicht verifiziert:** Android-Kompilierung, GitHub-Commit/Workflow, APK-Installation und reale UI-Funktion auf einem Gerät. Hier steht kein Android-SDK bereit.
- Für die direkte Bearbeitung des GitHub-Repositories benötigt der GitHub-Connector Zugriff auf `mebert1805-alt/NeoKI-Android`; der bisherige Lesezugriff lieferte `404` bzw. keine zugänglichen Repositories.
