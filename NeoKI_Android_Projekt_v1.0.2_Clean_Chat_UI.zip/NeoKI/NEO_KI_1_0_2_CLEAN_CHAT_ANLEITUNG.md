# NEO KI 1.0.2 – Clean Chat UI

Dieses Paket basiert auf der vom Nutzer bereitgestellten **Neo KI 1.0.1 – Compact Neon**-Projekt-ZIP. Es enthält das **Android-/Kotlin-Projekt mit angepasster Oberfläche**, keine Web-Demo und keine bereits gebaute APK.

## Was wurde geändert?

- **Chat als Mittelpunkt:** Begrüßung „Hallo! Ich bin Neo.“ und vier kleine Startaktionen, statt einer großen Funktionswerbekarte.
- **Seitenmenü (☰):** Hier findest du Chat, Bilder, Wissen, Gedächtnis und Setup. Die dauerhafte untere Fünfer-Navigation ist entfernt, damit mehr Platz für den Chat bleibt.
- **Neuer Chat:** über das Stift-Symbol oben oder das Seitenmenü. Ein bestehender Chat bzw. Entwurf wird erst nach Rückfrage gelöscht.
- **Plus-Menü beim Eingabefeld:** Bild auswählen, Dokument hinzufügen, Kamera öffnen und Spracheingabe. Dieselben Android-Launcher wie vorher.
- **Mikrofon:** direkt rechts neben dem leeren Eingabefeld; nach Eingabe oder Anhang erscheint stattdessen die Senden-Schaltfläche.
- **Antworten aufgeräumt:** keine Neon-Umrandung für jede KI-Antwort; Quellen, verwendetes Modell, Lernregeln und „Ins Wissen übernehmen“ sind unter „Aktionen & Details“ erreichbar. Prüf-Warnungen bleiben sofort sichtbar.
- **Layout:** auf Smartphone und Tablet nutzbar; beim Einblenden der Tastatur kann sich der Bildschirm in der Höhe anpassen.
- **Setup:** alle vier Compact-Neon-Karten und „Entwickelt von Marco Ebert“ bleiben vorhanden. Die „Über Neo KI“-Anzeige nennt Version 1.0.2.
- **Version:** `versionName = "1.0.2"`, `versionCode = 103`, identische Android-Paket-ID `de.neoki.app.cloud.neon100`.

### Unverändert geblieben

API-Code, Bild-/Dokumentverarbeitung, Spracherkennung über Android, SecretStore, Cloudflare-Server und serverseitige Tests. **Eine echte Projekteverwaltung oder eine dauerhafte Chat-Historie wurde nicht hinzugefügt**; die Startaktion „Projekt planen“ ist ein vorformulierter Chat-Einstieg.

## So geht es wie bisher auf GitHub weiter

Repository aus dem vorherigen Gespräch: https://github.com/mebert1805-alt/NeoKI-Android

1. Sichere die bestehende Version 1.0.1 und ggf. wichtige lokale Einstellungen.
2. Lade `NeoKI_Android_Projekt_v1.0.2_Clean_Chat_UI.zip` **als ZIP, ohne Entpacken**, in das Stammverzeichnis des Repositories hoch. Bei Nutzung des bisherigen Builds ist das gewollt, weil der Workflow die ZIP selber entpackt.
3. Öffne die vorhandene Workflow-Datei `.github/workflows/android-apk.yml` und suche die Zeile unter „Projekt entpacken“. Ersetze **nur den Dateinamen** im bisherigen `unzip`-Befehl. Wenn die Archivstruktur und der Extraktionsordner wie bei Version 1.0.1 sind, lautet die ganze Zeile:

   ```yaml
   run: unzip -q NeoKI_Android_Projekt_v1.0.2_Clean_Chat_UI.zip -d projekt
   ```

4. **Commit changes** speichern. Dann unter GitHub **Actions** den neuen Workflow überprüfen. Prüfe, ob der Gradle-Befehl nach dem Entpacken das Verzeichnis `projekt/NeoKI/android` verwendet.
5. Erst wenn GitHub Actions grün ist, das neue APK-Artifact herunterladen, entpacken und auf dem Telefon installieren.
6. Die neue APK muss mit derselben Signatur erstellt werden, damit sie direkt über Version 1.0.1 installiert werden kann. Bei Signaturproblemen die alte App nicht unbedacht deinstallieren: Dabei können lokal gespeicherte Einstellungen und Zugangsdaten verloren gehen.

Direkt-Links:

- ZIP-Upload: https://github.com/mebert1805-alt/NeoKI-Android/upload/main
- Workflow-Editor (falls der Pfad gleich blieb): https://github.com/mebert1805-alt/NeoKI-Android/edit/main/.github/workflows/android-apk.yml
- GitHub Actions: https://github.com/mebert1805-alt/NeoKI-Android/actions

## Testen nach Installation

1. Chat starten und Nachricht versenden; eine Antwort erhalten.
2. Plus-Menü öffnen und ein Bild, Dokument und Kamerafoto anhängen.
3. Mikrofon drücken, Spracherkennung starten und Text übernehmen.
4. Seitenmenü öffnen und Bilder/Wissen/Gedächtnis/Setup einzeln aufrufen.
5. Über Setup → KI-Einstellungen: bereits konfigurierte Serverdaten und Schalter prüfen, ohne Zugangsdaten zu veröffentlichen.
6. Unter „Über Neo KI“ die Version 1.0.2 und „Entwickelt von Marco Ebert“ prüfen.
7. Bei einer Neo-Antwort „Aktionen & Details“ öffnen, Quellen/Lernvorschläge/Wissensübernahme prüfen.
8. Leeren und gefüllten Chat sowohl im Hoch- als auch im Querformat testen.

## Verifizierung dieser Lieferung

- Basis: vom Nutzer bereitgestellte Neo-KI-v1.0.1-Projekt-ZIP.
- API, SecretStore, AttachmentTools, Cloudflare-Server und bestehende Servertests bytegenau unverändert.
- Server-Tests: **7 erfolgreich**.
- Kotlin-Dateien statisch auf Grundstruktur geprüft; **keine Android-Kompilierung und kein Gerätetest in dieser Umgebung**. Erst GitHub Actions kann zeigen, ob die APK baut.
- Die Datei wurde **nicht von hier aus nach GitHub hochgeladen**.
