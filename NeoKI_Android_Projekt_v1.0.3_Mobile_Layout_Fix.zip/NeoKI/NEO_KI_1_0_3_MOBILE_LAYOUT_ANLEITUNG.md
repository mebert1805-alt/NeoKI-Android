# Neo KI 1.0.3 – Mobile Layout Fix

Ergänzung zu v1.0.2 Clean Chat UI. **Tablet-Layout und sämtliche API-/Serverfunktionen bleiben unverändert.**

- Abstand zur Statusleiste (Uhrzeit, Notch, Kameraausschnitt) im Compose-Top-Bar ergänzt.
- Kopfzeile auf schmalen Smartphones verkleinert; Text wird bei Bedarf mit Auslassungspunkten gekürzt.
- Startseite passt Logo, Abstände und Einstiegstasten an schmale/kurze Displays an.
- Auf sehr schmalen Geräten sind die Einstiegstasten einspaltig und scrollbar.
- Chatbereich berücksichtigt zusätzlich die Bildschirmtastatur (IME).
- Eingabe- und Anhängeaktionen behalten große Tippflächen, brauchen aber weniger Breite.
- Versionsnummer: 1.0.3 (Code 104). App-ID unverändert.

**Wichtig zur Diagnose:** Die vorgelegten Screenshots zeigen noch die alte große Begrüßungskarte und fünf Reiter unten. Das entspricht der früheren v1.0.1-Oberfläche, nicht der Clean-Chat-Oberfläche aus v1.0.2/1.0.3. Nach dem Build im Setup unter „Über Neo KI“ die Versionsnummer **1.0.3** prüfen.

## GitHub-Workflow wie bisher

1. ZIP direkt im Repository hochladen, nicht entpacken.
2. Vorhandenen `unzip`-Schritt des Android-Build-Workflows anpassen:

```yaml
run: unzip -q NeoKI_Android_Projekt_v1.0.3_Mobile_Layout_Fix.zip -d projekt
```

3. Commit, dann GitHub Actions. Der Workflow muss die Android-App aus `projekt/NeoKI/android` bauen.
4. Erst nach erfolgreichem Build die APK herunterladen und installieren.

Vor dem Installieren bei bestehender App am besten alle wichtigen lokalen Daten sichern. Bei Signaturkonflikt die alte App nicht ohne Backup entfernen.

**Hier nicht geprüft:** Android-Kompilierung und echte Gerätedarstellung. Das Projekt muss in GitHub Actions gebaut und auf Smartphone + Tablet getestet werden.
