package de.neoki.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Neo KI 1.0.3: bewusst reduzierte Begrüßung statt der alten großen Neon-Werbekarte.
 * Alle Aktionen delegieren an die vorhandenen Launcher/Chat-Funktionen in MainActivity.
 */
@Composable
internal fun NeoCleanWelcome(
    modifier: Modifier = Modifier,
    onWrite: () -> Unit,
    onImage: () -> Unit,
    onDocument: () -> Unit,
    onProject: () -> Unit
) {
    // The welcome view must fit a narrow phone without resizing the whole app.
    // Tablets retain the larger, two-column design.
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val phone = maxWidth < 600.dp
        val veryNarrow = maxWidth < 345.dp
        val shortScreen = maxHeight < 520.dp
        val horizontalPadding = if (phone) 16.dp else 20.dp
        val logoSize = if (shortScreen) 44.dp else if (phone) 56.dp else 68.dp
        val actionGap = if (phone) 8.dp else 10.dp

        Column(
            modifier = Modifier.widthIn(max = 510.dp).fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = horizontalPadding, vertical = if (shortScreen) 8.dp else 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.mipmap.ic_launcher),
                contentDescription = "Neo KI Logo",
                modifier = Modifier.size(logoSize).clip(CircleShape)
            )
            Spacer(Modifier.height(if (phone) 12.dp else 20.dp))
            Text(
                "Hallo! Ich bin Neo. ✦",
                color = NeoText,
                fontSize = if (phone) 23.sp else 25.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Wie kann ich dir heute helfen?",
                color = NeoMuted,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(if (shortScreen) 16.dp else if (phone) 22.dp else 30.dp))
            if (veryNarrow) {
                // No fixed-width cards: small displays get four full-width entries.
                NeoStarterAction("✎", "Text schreiben", NeoCyan, Modifier.fillMaxWidth(), onWrite, compact = true)
                Spacer(Modifier.height(actionGap))
                NeoStarterAction("▧", "Bild analysieren", NeoBlue, Modifier.fillMaxWidth(), onImage, compact = true)
                Spacer(Modifier.height(actionGap))
                NeoStarterAction("▤", "Dokument prüfen", NeoPurple, Modifier.fillMaxWidth(), onDocument, compact = true)
                Spacer(Modifier.height(actionGap))
                NeoStarterAction("◇", "Projekt planen", NeoPink, Modifier.fillMaxWidth(), onProject, compact = true)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(actionGap)) {
                    NeoStarterAction("✎", "Text schreiben", NeoCyan, Modifier.weight(1f), onWrite, compact = phone)
                    NeoStarterAction("▧", "Bild analysieren", NeoBlue, Modifier.weight(1f), onImage, compact = phone)
                }
                Spacer(Modifier.height(actionGap))
                Row(horizontalArrangement = Arrangement.spacedBy(actionGap)) {
                    NeoStarterAction("▤", "Dokument prüfen", NeoPurple, Modifier.weight(1f), onDocument, compact = phone)
                    NeoStarterAction("◇", "Projekt planen", NeoPink, Modifier.weight(1f), onProject, compact = phone)
                }
            }
        }
    }
}

@Composable
private fun NeoStarterAction(
    symbol: String,
    label: String,
    tint: Color,
    modifier: Modifier,
    onClick: () -> Unit,
    compact: Boolean = false
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.heightIn(min = if (compact) 52.dp else 60.dp),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, NeoOutline.copy(alpha = 0.7f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = NeoPanelSoft,
            contentColor = NeoText
        ),
        contentPadding = PaddingValues(horizontal = if (compact) 6.dp else 9.dp, vertical = 8.dp)
    ) {
        Text(symbol, fontSize = if (compact) 16.sp else 18.sp, color = tint)
        Spacer(Modifier.width(if (compact) 5.dp else 7.dp))
        Text(label, fontSize = if (compact) 11.sp else 12.sp, maxLines = 2,
            lineHeight = 14.sp, textAlign = TextAlign.Start)
    }
}

/** Gemeinsame Seitennavigation: alle existierenden Hauptbereiche bleiben erreichbar. */
@Composable
internal fun NeoSideMenu(
    current: Int,
    configured: Boolean,
    canNewChat: Boolean,
    canAddLesson: Boolean,
    onSelect: (Int) -> Unit,
    onNewChat: () -> Unit,
    onLearningRule: () -> Unit,
    onAbout: () -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = NeoPanel,
        drawerContentColor = NeoText,
        modifier = Modifier.widthIn(max = 320.dp)
    ) {
        Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.mipmap.ic_launcher),
                    contentDescription = null,
                    modifier = Modifier.size(46.dp).clip(CircleShape)
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Neo KI", fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
                    Text("Compact Neon · 1.0.3", color = NeoMuted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                if (configured) "● Server eingerichtet" else "● Einrichtung erforderlich",
                color = if (configured) NeoMint else NeoPink,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(22.dp))
            HorizontalDivider(color = NeoOutline.copy(alpha = 0.6f))
            Spacer(Modifier.height(12.dp))

            listOf(
                Triple("✦", "Chat", 0),
                Triple("▧", "Bilder", 1),
                Triple("◇", "Wissen", 2),
                Triple("♡", "Gedächtnis", 3),
                Triple("⚙", "Setup", 4)
            ).forEach { (symbol, label, index) ->
                NavigationDrawerItem(
                    label = { Text(label, fontWeight = if (current == index) FontWeight.Bold else FontWeight.Normal) },
                    selected = current == index,
                    icon = { Text(symbol, color = if (current == index) NeoCyan else NeoMuted, fontSize = 22.sp) },
                    onClick = { onSelect(index) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = NeoPurplePanel,
                        selectedTextColor = NeoText,
                        unselectedTextColor = NeoMuted,
                        unselectedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = NeoOutline.copy(alpha = 0.6f))
            Spacer(Modifier.height(12.dp))
            Text("CHAT-AKTIONEN", fontSize = 11.sp, color = NeoMuted, modifier = Modifier.padding(horizontal = 12.dp))
            TextButton(onClick = onNewChat, enabled = canNewChat, modifier = Modifier.fillMaxWidth()) {
                Text("＋  Neuer Chat", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
            }
            TextButton(onClick = onLearningRule, enabled = canAddLesson, modifier = Modifier.fillMaxWidth()) {
                Text("✦  Lernregel hinzufügen", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) {
                Text("ⓘ  Über Neo KI", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
            }
        }
    }
}
