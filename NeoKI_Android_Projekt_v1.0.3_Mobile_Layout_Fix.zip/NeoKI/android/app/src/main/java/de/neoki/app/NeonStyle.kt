package de.neoki.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Neo KI 1.0.3: Farben und wiederverwendbare UI-Bausteine. Keine Netzwerkaenderungen.
internal val NeoBackground = Color(0xFF050A1C)
internal val NeoDeepBlue = Color(0xFF0A1030)
internal val NeoPanel = Color(0xFF101734)
internal val NeoPanelSoft = Color(0xFF0C1430)
internal val NeoPurplePanel = Color(0xFF2A155B)
internal val NeoOutline = Color(0xFF354878)
internal val NeoBlue = Color(0xFF357CFF)
internal val NeoCyan = Color(0xFF1FE6ED)
internal val NeoPurple = Color(0xFFA653FF)
internal val NeoPink = Color(0xFFFE64C4)
internal val NeoMint = Color(0xFF65EDC0)
internal val NeoText = Color(0xFFF8FAFF)
internal val NeoMuted = Color(0xFFB4C2E5)
internal val NeoWarningPanel = Color(0xFF482034)

@Composable
internal fun NeonActionButton(
    symbol: String,
    label: String,
    tint: Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(15.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = if (enabled) 0.95f else 0.35f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = tint.copy(alpha = 0.17f),
            contentColor = NeoText,
            disabledContainerColor = NeoPanelSoft,
            disabledContentColor = NeoMuted
        ),
        contentPadding = PaddingValues(horizontal = 13.dp, vertical = 9.dp)
    ) {
        Text(symbol, fontSize = 17.sp, color = tint)
        Spacer(Modifier.width(7.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
internal fun NeonWelcomePanel(modifier: Modifier = Modifier, compact: Boolean = false) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .border(1.dp, Brush.linearGradient(listOf(NeoCyan, NeoBlue, NeoPurple, NeoPink)), shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(NeoPurplePanel, NeoPanel, NeoDeepBlue)))
            .padding(if (compact) 20.dp else 16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().then(
                if (compact) Modifier else Modifier.verticalScroll(rememberScrollState())
            ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher),
                contentDescription = "Neo KI Neon-Logo",
                modifier = Modifier.size(if (compact) 82.dp else 116.dp).clip(CircleShape)
            )
            Text(
                "Hallo! Ich bin Neo. ✦",
                fontWeight = FontWeight.ExtraBold,
                fontSize = if (compact) 22.sp else 21.sp,
                color = NeoText,
                textAlign = TextAlign.Center
            )
            Text(
                "Dein intelligenter Assistent – mit Gedächtnis, Bildern und Dokumenten.",
                fontSize = 13.sp, color = NeoMuted, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(2.dp))
            WelcomeFeature("✦", "Intelligente Antworten", "Fragen und Recherche", NeoPurple)
            WelcomeFeature("▧", "Multimodal", "Bilder, Dokumente, Kamera", NeoCyan)
            WelcomeFeature("♡", "Persönlich", "Dein Wissen und Gedächtnis", NeoPink)
        }
    }
}

@Composable
private fun WelcomeFeature(symbol: String, title: String, description: String, tint: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(37.dp)
                .border(1.dp, tint.copy(alpha = 0.65f), RoundedCornerShape(11.dp))
                .background(tint.copy(alpha = 0.13f), RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) { Text(symbol, color = tint, fontSize = 22.sp) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = NeoText, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(description, color = NeoMuted, fontSize = 10.sp)
        }
    }
}
